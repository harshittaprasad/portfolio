/* ==========================================================================
   Work: three sections side by side, like an accordion.

   At rest the three panels share the width equally: an image at the top and
   the section's name, too big to fit, cut off along the bottom. Pointing at
   (or focusing, or tapping) a panel opens it: it takes almost all the width,
   the other two fold into thin strips, and the open panel shows its number,
   a short description, its images in turn, and its name spread across the
   full width. On narrow screens the same thing happens top to bottom.
   ========================================================================== */
(function () {
  'use strict';

  /* ---------- sections: edit these ----------
     n     : the number shown on the panel
     name  : the big word along the bottom
     tag   : two or three short lines under the number (use \n for a break)
     text  : one or two sentences of small print
     tone  : 'bone', 'ink' or 'ochre' (the panel colour)
     media : images or videos shown in turn while the panel is open, e.g.
             ['../assets/img/work/app-01.jpg', '../assets/img/work/reel.mp4']
             (an empty list shows a placeholder)
     href  : where the panel leads, e.g. '../work/case-studies/' (null = not yet) */
  const SECTIONS = [
    {
      n: '00-1', name: 'Case Studies', tone: 'bone',
      tag: 'Research, journeys,\nwireframes & testing',
      text: 'End-to-end UX projects: what the problem was, how I got to an answer, and what changed because of it.',
      media: [], href: null,
    },
    {
      n: '00-2', name: 'Interface', tone: 'ink',
      tag: 'Apps, websites\n& design systems',
      text: 'Screens, components and the small interactions in between them.',
      media: [], href: null,
    },
    {
      n: '00-3', name: 'Graphics', tone: 'ochre',
      tag: 'Posters, branding,\ntype & layout',
      text: 'Visual work beyond the screen: identities, posters and editorial pieces.',
      media: [], href: null,
    },
  ];

  const SLIDE_MS = 2800;     // time each image stays up while a panel is open
  const LEAVE_MS = 350;      // grace period before the panels settle back to equal

  const acc = document.getElementById('acc');
  if (!acc) return;

  const doc = document.documentElement;
  const touch = matchMedia('(hover: none)').matches;
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const isVideo = (src) => /\.(mp4|webm|mov)(\?|$)/i.test(src);

  /* ---------- build ---------- */

  const panels = SECTIONS.map((s, i) => {
    const el = document.createElement(s.href ? 'a' : 'div');
    el.className = 'panel panel--' + s.tone;
    el.setAttribute('role', 'listitem');
    el.style.setProperty('--i', String(i));
    if (s.href) el.href = s.href; else el.tabIndex = 0;
    el.setAttribute('aria-label', s.n + ', ' + s.name + '. ' + s.tag.replace(/\n/g, ' ') + '.' + (s.href ? '' : ' Coming soon.'));

    const slides = s.media.length
      ? s.media.map((src, k) => isVideo(src)
          ? '<video class="slide' + (k ? '' : ' is-on') + '" src="' + esc(src) + '" muted loop playsinline preload="metadata"></video>'
          : '<img class="slide' + (k ? '' : ' is-on') + '" src="' + esc(src) + '" alt="" loading="lazy" decoding="async" draggable="false">').join('')
      : '<span class="slide slide--ph is-on"><span>' + esc(s.n) + '</span></span>';

    const letters = Array.from(s.name.toUpperCase()).map((c) =>
      c === ' ' ? '<span class="gap"></span>' : '<span>' + esc(c) + '</span>').join('');

    el.innerHTML =
      '<span class="panel__media">' + slides + '</span>' +
      '<span class="panel__num">' + esc(s.n) + '</span>' +
      '<span class="panel__info">' +
        '<span class="panel__tag">' + esc(s.tag).replace(/\n/g, '<br>') + '</span>' +
        '<span class="panel__text">' + esc(s.text) + '</span>' +
        '<span class="panel__more">' + (s.href ? 'View all&ensp;→' : '(&ensp;Coming soon&ensp;)') + '</span>' +
      '</span>' +
      '<span class="panel__mini">' + esc(s.n) + '</span>' +
      '<span class="panel__word" aria-hidden="true">' + letters + '</span>' +
      '<span class="panel__strip" aria-hidden="true">' +
        '<span class="strip__num">' + esc(s.n) + '</span>' +
        '<span class="strip__label">' + esc(s.name) + '</span>' +
      '</span>';

    acc.appendChild(el);
    return { el, s, word: el.querySelector('.panel__word'), slides: el.querySelectorAll('.slide'), k: 0, timer: 0 };
  });

  /* ---------- fit the big words ----------
     All three words share one size: the longest fills the open panel's width
     (but never more than about a third of its height). Shorter words are
     spread letter by letter to the same width when open, and sit at their
     natural width when the panels are equal. */

  const probe = document.createElement('span');
  probe.className = 'panel__word panel__word--probe';
  probe.setAttribute('aria-hidden', 'true');
  acc.appendChild(probe);
  // reads the strip width and panel padding back from the CSS, in px
  const ruler = document.createElement('span');
  ruler.className = 'acc__ruler';
  ruler.setAttribute('aria-hidden', 'true');
  acc.appendChild(ruler);

  const fit = () => {
    const vertical = getComputedStyle(acc).flexDirection === 'column';
    const strip = ruler.offsetWidth || 56;
    const pp = ruler.offsetHeight || 20;
    const W = acc.clientWidth, H = acc.clientHeight;
    const openW = (vertical ? W : W - 2 * strip) - 2 * pp;
    const openH = vertical ? H - 2 * strip : H;

    const nat = panels.map((p) => { probe.textContent = p.s.name.toUpperCase(); return probe.getBoundingClientRect().width; });
    const ref = parseFloat(getComputedStyle(probe).fontSize);
    let size = ref * openW / Math.max(...nat);
    size = Math.min(size, openH * (vertical ? .2 : .36));

    acc.style.setProperty('--word-size', size.toFixed(1) + 'px');
    acc.style.setProperty('--open-w', openW.toFixed(1) + 'px');
    panels.forEach((p, i) => p.el.style.setProperty('--nat-w', Math.min(openW, nat[i] * size / ref).toFixed(1) + 'px'));
  };

  /* ---------- open / close ---------- */

  let open = null;
  let leaveTimer = 0;

  const play = (p, on) => {
    clearInterval(p.timer);
    p.slides.forEach((v) => { if (v.tagName === 'VIDEO') { if (on) v.play().catch(() => {}); else v.pause(); } });
    if (!on || reduce || p.slides.length < 2) return;
    p.timer = setInterval(() => {
      p.slides[p.k].classList.remove('is-on');
      p.k = (p.k + 1) % p.slides.length;
      p.slides[p.k].classList.add('is-on');
    }, SLIDE_MS);
  };

  const setOpen = (p) => {
    clearTimeout(leaveTimer);
    if (open === p) return;
    if (open) { open.el.classList.remove('is-open'); play(open, false); }
    open = p;
    acc.classList.toggle('has-open', !!p);
    if (p) { p.el.classList.add('is-open'); play(p, true); }
  };

  panels.forEach((p) => {
    p.el.addEventListener('pointerenter', (e) => { if (e.pointerType !== 'touch') setOpen(p); });
    p.el.addEventListener('focus', () => setOpen(p));
    // touch: the first tap opens a panel, the second follows its link
    p.el.addEventListener('pointerdown', () => { p.wasOpen = open === p; });
    p.el.addEventListener('click', (e) => {
      if (touch && !p.wasOpen) { e.preventDefault(); setOpen(p); }
    });
  });

  acc.addEventListener('pointerleave', (e) => {
    if (e.pointerType === 'touch') return;
    leaveTimer = setTimeout(() => { if (!acc.contains(document.activeElement)) setOpen(null); }, LEAVE_MS);
  });
  acc.addEventListener('focusout', (e) => { if (!acc.contains(e.relatedTarget)) setOpen(null); });

  /* ---------- sizes ---------- */

  const fonts = document.fonts && document.fonts.ready ? document.fonts.ready : Promise.resolve();
  fit();
  fonts.then(fit);
  let rz = 0;
  addEventListener('resize', () => { cancelAnimationFrame(rz); rz = requestAnimationFrame(fit); });

  doc.classList.add('work-built');
})();
