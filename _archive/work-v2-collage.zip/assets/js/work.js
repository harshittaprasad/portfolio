/* ==========================================================================
   Work: a pile of projects on the table.

   Each project is a different paper object (a black card, a pinstripe card,
   a punched sheet, a polaroid, a print) laid in a fixed composition, with an
   index sheet underneath. Images show in black and white until a piece is
   hovered or focused; then it lifts, takes its colour back, the rest of the
   pile dims, and its title appears in the bottom-right corner.
   ========================================================================== */
(function () {
  'use strict';

  /* ---------- projects: replace these with real ones ----------
     title : project name
     type  : what it is, e.g. 'UX case study', 'App redesign'
     year  : '2026'
     image : path to a cover image, e.g. '../assets/img/work/project-01.jpg'
             (any shape works, it is cropped to fit its piece)
     href  : where the piece links to, e.g. '../work/project-01/' (null = not yet)
     The first five fill the composition in order:
     black card, pinstripe card, punched sheet, polaroid, wide print. */
  const PROJECTS = [
    { title: 'Project One',   type: 'UX case study',   year: '2026', image: null, href: null },
    { title: 'Project Two',   type: 'App design',      year: '2026', image: null, href: null },
    { title: 'Project Three', type: 'Research',        year: '2025', image: null, href: null },
    { title: 'Project Four',  type: 'Interaction',     year: '2025', image: null, href: null },
    { title: 'Project Five',  type: 'Website',         year: '2025', image: null, href: null },
  ];

  /* ---------- composition ----------
     The pile is 100 wide by 80 tall. x, y, w are in those units, r in degrees,
     ratio is width / height of the piece. */
  const SLOTS = [
    { kind: 'noir',     x: 15, y: 17, w: 33, ratio: .80, r: -4.5, z: 5, clip: 33 },
    { kind: 'stripe',   x: 43, y: 10, w: 31, ratio: .72, r: 3,    z: 6, clip: 54 },
    { kind: 'dots',     x: 66, y: 3,  w: 29, ratio: .76, r: 4.5,  z: 3 },
    { kind: 'polaroid', x: 71, y: 46, w: 23, ratio: .84, r: 7,    z: 7, tape: true },
    { kind: 'print',    x: 11, y: 52, w: 62, ratio: 2.45, r: -1.5, z: 2 },
  ];
  const SHEET = { x: 1, y: 3, w: 39, ratio: .72, r: -7, z: 1 };

  const pile = document.getElementById('pile');
  const caption = document.getElementById('pileCaption');
  const count = document.getElementById('pileCount');
  if (!pile) return;

  const touch = matchMedia('(hover: none)').matches;
  const pad2 = (n) => String(n).padStart(2, '0');
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  const STAR = '<svg class="star" viewBox="0 0 24 24" aria-hidden="true"><polygon points="12,.5 14.12,9.09 22.94,8.45 15.42,13.11 18.76,21.3 12,15.6 5.24,21.3 8.58,13.11 1.06,8.45 9.88,9.09"/></svg>';
  const CLIP = '<svg class="clip" viewBox="0 0 60 66" aria-hidden="true">' +
    '<path class="clip__wire" d="M18 36 L14 7 Q13.6 3 17.6 3 H42.4 Q46.4 3 46 7 L42 36"/>' +
    '<path class="clip__body" d="M7 32 H53 L58.5 61 Q59 64 56 64 H4 Q1 64 1.5 61 Z"/>' +
    '<path class="clip__shine" d="M10 35.5 H50"/></svg>';

  // pseudo-random but stable, for any project past the fifth
  let seed = 11;
  const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };

  const place = (el, s) => {
    el.style.left = s.x + '%';
    el.style.top = (s.y / 80 * 100) + '%';
    el.style.width = s.w + '%';
    el.style.aspectRatio = String(s.ratio);
    el.style.zIndex = String(s.z);
    el.style.setProperty('--r', s.r + 'deg');
  };

  /* ---------- the index sheet underneath ---------- */

  const sheet = document.createElement('div');
  sheet.className = 'piece piece--sheet';
  sheet.setAttribute('aria-hidden', 'true');
  place(sheet, SHEET);
  sheet.style.setProperty('--d', '0');
  sheet.innerHTML =
    '<span class="sheet__head"><span>Index</span><span>H.P. — 2026</span></span>' +
    '<span class="sheet__list">' + PROJECTS.map((p, i) =>
      '<span class="sheet__row"><span>' + pad2(i + 1) + '</span><span>' + esc(p.title) +
      '</span><span class="sheet__dots"></span><span>' + esc(p.year) + '</span></span>').join('') +
    '</span>' +
    '<span class="sheet__foot">selected work,<br>in no particular order.</span>';
  pile.appendChild(sheet);

  /* ---------- the projects ---------- */

  const pieces = PROJECTS.map((p, i) => {
    const slot = SLOTS[i] || {
      kind: 'print', ratio: 1.3, w: 26, z: 8 + i,
      x: 8 + rnd() * 62, y: 6 + rnd() * 50, r: (rnd() - .5) * 12,
    };
    const n = pad2(i + 1);
    const el = document.createElement(p.href ? 'a' : 'div');
    el.className = 'piece piece--' + slot.kind + (p.image ? ' has-image' : '');
    el.setAttribute('role', 'listitem');
    el.setAttribute('aria-label', n + ', ' + p.title + ', ' + p.type + ', ' + p.year + (p.href ? '' : ', coming soon'));
    if (p.href) el.href = p.href; else el.tabIndex = 0;
    place(el, slot);
    el.style.setProperty('--d', String(260 + i * 130));

    const face = p.image
      ? '<img src="' + esc(p.image) + '" alt="" loading="lazy" decoding="async" draggable="false">'
      : '<span class="ph">' + (slot.kind === 'noir' ? STAR : '') + '<span class="ph__n">' + n + '</span></span>';

    let label = '';
    if (slot.kind === 'noir' || slot.kind === 'stripe') label = '<span class="piece__strip">' + n + ' — ' + esc(p.title) + '</span>';
    if (slot.kind === 'polaroid') label = '<span class="piece__hand">' + n + ', ' + esc(p.title.toLowerCase()) + '</span>';
    if (slot.kind === 'print' || slot.kind === 'dots') label = '<span class="piece__mark">' + n + ' / ' + esc(p.type) + '</span>';

    el.innerHTML =
      '<span class="piece__face">' + face + '</span>' + label +
      (slot.kind === 'dots' ? '<span class="piece__holes"></span>' : '') +
      (slot.clip ? '<span class="piece__clip" style="left:' + (slot.clip - slot.x) / slot.w * 100 + '%">' + CLIP + '</span>' : '') +
      (slot.tape ? '<span class="piece__tape"></span>' : '');

    pile.appendChild(el);
    return { el, p, n };
  });

  if (count) count.textContent = '(' + pad2(PROJECTS.length) + ')';

  /* ---------- focus: one piece at a time ---------- */

  const hint = caption ? caption.innerHTML : '';
  if (touch && caption) caption.innerHTML = hint.replace('Hover', 'Tap');
  const idle = caption ? caption.innerHTML : '';
  let active = null;

  const show = (item) => {
    if (active === item) return;
    if (active) active.el.classList.remove('is-active');
    active = item;
    pile.classList.toggle('has-active', !!item);
    if (!caption) return;
    if (!item) { caption.innerHTML = idle; return; }
    item.el.classList.add('is-active');
    caption.innerHTML = item.n + ' — ' + esc(item.p.title) + '<br>' +
      '<span class="micro--quiet">' + esc(item.p.type) + ', ' + esc(item.p.year) +
      (item.p.href ? '' : ' · coming soon') + '</span>';
  };

  pieces.forEach((item) => {
    item.el.addEventListener('pointerenter', (e) => { if (e.pointerType !== 'touch') show(item); });
    item.el.addEventListener('pointerleave', (e) => { if (e.pointerType !== 'touch') show(null); });
    item.el.addEventListener('focus', () => show(item));
    item.el.addEventListener('blur', () => show(null));
    // touch: the first tap lifts a piece, the second follows its link
    // (read before the tap's own focus event has already lifted it)
    item.el.addEventListener('pointerdown', () => { item.wasActive = active === item; });
    item.el.addEventListener('click', (e) => {
      if (touch && !item.wasActive) { e.preventDefault(); show(item); }
    });
  });

  // tap on the empty table puts the piece back down
  document.addEventListener('click', (e) => {
    if (active && !e.target.closest('.piece')) show(null);
  });
})();
