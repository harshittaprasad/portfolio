/* Every page: smooth scroll, page fade in/out, scroll reveals, the fixed
   footer's space, the cursor badge, and folder links when opened from disk. */
(() => {
  const root = document.documentElement;
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

  // Smooth scrolling, like the reference. Falls back to native scrolling.
  if (window.Lenis && !reduce) {
    const lenis = new Lenis({ lerp: 0.1 });
    const raf = (t) => { lenis.raf(t); requestAnimationFrame(raf); };
    requestAnimationFrame(raf);
    window.lenis = lenis;
  }

  // Opened straight from disk: folder links need an explicit index.html.
  if (location.protocol === 'file:') {
    document.querySelectorAll('a[href]').forEach((a) => {
      const href = a.getAttribute('href');
      if (/^[a-z]+:|^\/\/|^#/i.test(href)) return;
      const [path, hash] = href.split('#');
      if (path === '' || path.endsWith('/') || path === '.' || path === '..') {
        const base = path === '.' || path === '..' ? path + '/' : path;
        a.setAttribute('href', base + 'index.html' + (hash ? '#' + hash : ''));
      }
    });
  }

  // The footer is fixed under the page; keep exactly enough room for it.
  const foot = document.querySelector('.site-footer');
  if (foot) {
    const fit = () => root.style.setProperty('--foot-h', foot.offsetHeight + 'px');
    fit();
    new ResizeObserver(fit).observe(foot);
  }

  // Fade the page in once the fonts have arrived.
  const ready = () => root.classList.add('is-ready');
  (document.fonts ? document.fonts.ready : Promise.resolve()).then(() => requestAnimationFrame(ready));
  setTimeout(ready, 1500);

  // [data-reveal] fades up the first time it scrolls into view.
  const io = new IntersectionObserver((entries) => {
    entries.forEach((e) => {
      if (!e.isIntersecting) return;
      e.target.classList.add('is-in');
      io.unobserve(e.target);
    });
  }, { rootMargin: '0px 0px -6% 0px' });
  const watch = () => document.querySelectorAll('[data-reveal]:not(.is-in)').forEach((el) => io.observe(el));
  if (root.classList.contains('is-ready')) watch();
  else new MutationObserver((_, mo) => {
    if (root.classList.contains('is-ready')) { mo.disconnect(); watch(); }
  }).observe(root, { attributes: true, attributeFilter: ['class'] });

  // Fade out before leaving for another page of the site.
  document.addEventListener('click', (e) => {
    const a = e.target.closest('a[href]');
    if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    if (a.target === '_blank' || a.hasAttribute('download')) return;
    const url = new URL(a.href, location.href);
    if (!/^(https?|file):$/.test(url.protocol) || url.origin !== location.origin) return;
    if (url.pathname === location.pathname && url.search === location.search) return;
    e.preventDefault();
    root.classList.add('is-leaving');
    setTimeout(() => { location.href = url.href; }, reduce ? 0 : 330);
  });
  addEventListener('pageshow', (e) => { if (e.persisted) root.classList.remove('is-leaving'); });

  // "Back to top"
  document.querySelectorAll('[data-top]').forEach((b) => b.addEventListener('click', (e) => {
    e.preventDefault();
    if (window.lenis) window.lenis.scrollTo(0, { duration: 1.6 });
    else scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' });
  }));

  // A ring with an arrow follows the pointer over anything marked [data-badge].
  const badge = document.querySelector('.badge');
  if (badge && matchMedia('(hover: hover)').matches) {
    let x = -200, y = -200, tx = x, ty = y, seen = false;
    const check = () => {
      const el = document.elementFromPoint(tx, ty);
      badge.classList.toggle('is-on', !!(el && el.closest('[data-badge]')));
    };
    addEventListener('pointermove', (e) => {
      tx = e.clientX; ty = e.clientY;
      if (!seen) { x = tx; y = ty; seen = true; }
      check();
    }, { passive: true });
    addEventListener('scroll', check, { passive: true });
    document.documentElement.addEventListener('pointerleave', () => badge.classList.remove('is-on'));
    const follow = () => {
      x += (tx - x) * 0.22; y += (ty - y) * 0.22;
      badge.style.setProperty('--x', x.toFixed(1) + 'px');
      badge.style.setProperty('--y', y.toFixed(1) + 'px');
      requestAnimationFrame(follow);
    };
    follow();
  }
})();
