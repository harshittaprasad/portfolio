/* Home: the scroll story on one pinned stage.
   1. blobs grow over the logo and open onto the first picture
   2. each next picture grows out of the middle of the one before
   3. on the last picture the side words slide in and the folder grows */
(() => {
  const scene = document.querySelector('.scene');
  if (!scene) return;
  const stage = scene.querySelector('.stage');
  const hero = stage.querySelector('.hero');
  const framesEl = stage.querySelector('.frames');
  const frames = [...framesEl.querySelectorAll('.frame')];
  const folder = stage.querySelector('.folder');
  const sides = [stage.querySelector('.side--l'), stage.querySelector('.side--r')];

  // How long each part lasts, in screen heights of scrolling.
  const REVEAL = 1;       // blobs opening
  const ZOOM = 0.95;      // each picture-into-picture step
  const FINALE = 0.9;     // side words + folder
  const HOLD = 0.45;      // a pause before the page moves on
  const STEPS = frames.length - 1;
  const TOTAL = REVEAL + STEPS * ZOOM + FINALE + HOLD;

  const REST = 0.14;      // share of each step spent on the full picture before the next appears
  const SMALL = 0.085;    // size of a new picture when it appears (share of the screen)
  const PUSH = 0.55;      // how much the outgoing picture zooms in

  // Blobs: where they start (share of the screen), final size (share of the
  // diagonal), when they start (share of the reveal) and a wobble seed.
  const BLOBS = [
    { x: 0.58, y: 0.6, r: 0.85, at: 0, seed: 0 },
    { x: 0.27, y: 0.2, r: 0.5, at: 0.06, seed: 2.1 },
    { x: 0.18, y: 0.84, r: 0.4, at: 0.18, seed: 4.4 },
  ];

  const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
  const ease = (t) => t * t * (3 - 2 * t);
  const easeOut = (t) => 1 - Math.pow(1 - t, 3);
  const easeInOut = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

  let W = 0, H = 0, top = 0, lastKey = null;

  function measure() {
    W = stage.clientWidth;
    H = stage.clientHeight;
    scene.style.height = Math.round((TOTAL + 1) * H) + 'px';
    top = scene.getBoundingClientRect().top + scrollY;
    lastKey = null;
  }

  // A smooth closed blob through ten wobbling points (Catmull-Rom to Bezier).
  function blobPath(cx, cy, r, phase, seed) {
    const n = 10, p = [];
    for (let k = 0; k < n; k++) {
      const a = (k / n) * Math.PI * 2;
      const w = 1 + 0.2 * Math.sin(a * 2 + seed + phase) + 0.1 * Math.sin(a * 3 - seed * 1.7 + phase * 1.4);
      p.push([cx + Math.cos(a) * r * w, cy + Math.sin(a) * r * w]);
    }
    const f = (v) => v.toFixed(1);
    let d = `M${f(p[0][0])} ${f(p[0][1])}`;
    for (let k = 0; k < n; k++) {
      const p0 = p[(k - 1 + n) % n], p1 = p[k], p2 = p[(k + 1) % n], p3 = p[(k + 2) % n];
      d += `C${f(p1[0] + (p2[0] - p0[0]) / 6)} ${f(p1[1] + (p2[1] - p0[1]) / 6)} ` +
           `${f(p2[0] - (p3[0] - p1[0]) / 6)} ${f(p2[1] - (p3[1] - p1[1]) / 6)} ${f(p2[0])} ${f(p2[1])}`;
    }
    return d + 'Z';
  }

  function reveal(r) {
    if (r >= 1) { framesEl.style.clipPath = 'none'; return; }
    const diag = Math.hypot(W, H);
    let d = '';
    for (const b of BLOBS) {
      const t = clamp((r - b.at) / (1 - b.at));
      if (t <= 0) continue;
      const e = ease(t);
      const cx = (b.x + (0.5 - b.x) * e * 0.5) * W;   // drift toward the middle as they grow
      const cy = (b.y + (0.5 - b.y) * e * 0.5) * H;
      d += blobPath(cx, cy, e * b.r * diag, r * 2.6, b.seed);
    }
    framesEl.style.clipPath = `path('${d || 'M0 0Z'}')`;
  }

  function zoom(z, r) {
    const seg = Math.min(Math.floor(z), STEPS - 1);
    const t = z - seg;
    const g = easeInOut(clamp((t - REST) / (1 - REST)));
    frames.forEach((fr, i) => {
      let show = false, scale = 1, alpha = 1;
      if (i === seg) {
        show = g < 1;
        scale = 1 + PUSH * g;
        if (i === 0) scale *= 1 + 0.12 * (1 - ease(r));   // settles while the blobs open
      } else if (i === seg + 1) {
        show = t > REST;
        scale = Math.pow(SMALL, 1 - g);
        alpha = clamp((t - REST) / 0.04);
      }
      fr.style.visibility = show ? 'visible' : 'hidden';
      if (show) {
        fr.style.transform = `scale(${scale.toFixed(4)})`;
        fr.style.opacity = alpha < 1 ? alpha.toFixed(3) : '';
      }
    });
  }

  function finale(f) {
    const e = easeOut(f);
    if (folder) folder.style.scale = (0.55 + 0.45 * e).toFixed(4);
    sides.forEach((el, i) => {
      if (!el) return;
      el.style.visibility = f > 0 ? 'visible' : 'hidden';
      el.style.translate = `${((1 - e) * (i ? 130 : -130)).toFixed(2)}% 0`;
    });
  }

  function update() {
    const s = (scrollY - top) / H;
    const key = Math.round(s * 4000);
    if (key === lastKey) return;
    lastKey = key;
    const r = clamp(s / REVEAL);
    reveal(r);
    hero.style.visibility = r >= 1 ? 'hidden' : '';
    zoom(clamp((s - REVEAL) / ZOOM, 0, STEPS), r);
    finale(clamp((s - REVEAL - STEPS * ZOOM) / FINALE));
  }

  measure();
  update();
  addEventListener('resize', () => { measure(); update(); });
  const loop = () => { update(); requestAnimationFrame(loop); };
  requestAnimationFrame(loop);
})();
