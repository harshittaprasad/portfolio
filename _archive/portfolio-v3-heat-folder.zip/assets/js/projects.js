/* Projects: the page opens on a folder in the middle. Clicking it opens the
   folder, the four sheets inside rise out, and each one flies to its place in
   the grid and becomes that project's cover. Coming from the folder at the end
   of the home page (projects/#open) it opens by itself. */
(() => {
  const root = document.documentElement;
  const desk = document.querySelector('.desk');
  const folder = desk && desk.querySelector('.desk__folder');
  const grid = document.querySelector('.grid');
  if (!folder || !grid) { root.classList.remove('is-shut'); return; }

  const sheets = [...desk.querySelectorAll('.desk__sheet')];
  const cards = [...grid.querySelectorAll('.card')];
  const title = document.querySelector('.projects__title');
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));

  // start at the top, with the page held still behind the folder
  if ('scrollRestoration' in history) history.scrollRestoration = 'manual';
  scrollTo(0, 0);
  if (window.lenis) window.lenis.stop();

  let opened = false;

  async function open() {
    if (opened) return;
    opened = true;
    folder.setAttribute('aria-expanded', 'true');
    folder.classList.add('is-open');
    if (location.hash === '#open') history.replaceState(null, '', location.pathname + location.search);
    if (!reduce) await wait(540);

    // where each sheet is right now; its card starts from there
    const from = sheets.map((s) => s.getBoundingClientRect());

    grid.classList.add('is-flight');
    grid.querySelectorAll('[data-reveal]').forEach((el) => el.classList.add('is-in'));
    root.classList.remove('is-shut');
    if (window.lenis) window.lenis.start();
    desk.classList.add('is-away');

    if (!reduce) {
      const parts = cards.map((card) => [card.querySelector('.card__media'), card.querySelector('.card__meta')]);
      parts.forEach(([media, meta], i) => {
        const to = media.getBoundingClientRect(), f = from[i % from.length];
        media.style.transformOrigin = '0 0';
        media.style.transform =
          `translate(${f.left - to.left}px, ${f.top - to.top}px) scale(${f.width / to.width}, ${f.height / to.height})`;
        meta.style.opacity = '0';
      });
      sheets.forEach((s) => { s.style.visibility = 'hidden'; });
      void grid.offsetWidth;   // commit the starting positions before letting go
      parts.forEach(([media, meta], i) => {
        const d = i * 70;
        media.style.transition = `transform 1s cubic-bezier(.22, 1, .36, 1) ${d}ms`;
        media.style.transform = '';
        meta.style.transition = `opacity .6s ease ${d + 550}ms`;
        meta.style.opacity = '';
      });
      await wait(1000 + cards.length * 70 + 600);
      parts.forEach(([media, meta]) => { media.style.cssText = ''; meta.style.cssText = ''; });
    }

    grid.classList.remove('is-flight');
    desk.classList.add('is-gone');
    if (title) title.focus({ preventScroll: true });
  }

  folder.addEventListener('click', open);

  // arriving from the home page's folder: let the page fade in, then open
  if (location.hash === '#open') {
    const go = () => setTimeout(open, reduce ? 0 : 380);
    if (root.classList.contains('is-ready')) go();
    else new MutationObserver((_, mo) => {
      if (root.classList.contains('is-ready')) { mo.disconnect(); go(); }
    }).observe(root, { attributes: true, attributeFilter: ['class'] });
  }
})();
