# Harshita Prasad: portfolio

Static site, no build step. Plain HTML, CSS and JavaScript.

One dark look across every page: near-black background, warm light type,
film grain, a soft lamp that follows the pointer, and a small star cursor.
Display type is Cormorant Garamond (upright + italic), the small print is
Archivo in uppercase, and the only accent is ochre, taken from the star in
the portrait.

```
index.html            Home: "welcome to my / portfolio", small print in three corners
work/index.html       Work + About on one page: the contents (five numbered sections over a
                      faded "WORK"), then About me below it at #about
about/index.html      Only forwards to work/#about, so old About links keep working
assets/css/base.css   Shared tokens, small print, header, grain, lamp, cursor, entrances
assets/css/home.css   Home layout
assets/css/work.css   Work layout
assets/css/about.css  The About me section (on the Work page)
assets/js/site.js     Star cursor, lamp, file:// link fix (all pages)
assets/js/page.js     Fades things in once the fonts are ready, and About once it scrolls
                      into view; moves the menu underline to the section on screen
assets/js/game.js     Home: the Fruit Ninja game behind "( Play now )" in the footer
assets/img/           favicon.svg, portrait.jpg
_archive/             Earlier versions, zipped: the ID-card site, two older Work pages,
                      and the separate About page
```

## Run locally

```bash
python3 -m http.server 5173
```

Then open http://localhost:5173. Opening `index.html` directly from disk also works.

## Things to fill in

- **Email and LinkedIn**: `hello@harshitaprasad.com` and `linkedin.com/in/harshitaprasad`
  are placeholders. They appear in `index.html` (footer) and `work/index.html` (About, top left).
- **Résumé**: the About page links to `assets/resume.pdf`. Put your PDF there with that name.
- **The photo**: `assets/img/portrait.jpg`. To change it, replace the file and bump
  the `?v=` on its `<img>` in `work/index.html`.

## Editing the About text

The text lives in the About section of `work/index.html`, one line per `<span class="ln">`. Each line is
spread to the full column width, so short lines get wide gaps, which is the look.
Keep lines under about 40 characters so they fit on phones. Add `ln--para` to the
first line of a new paragraph for a small gap above it.

## The Work page

A contents page: a faded "WORK" across the middle with five sections over it,
01 Case Studies, 02 Branding / Rebranding, 03 Graphic, 04 Research and
05 About Me (which scrolls down to the About section). Pointing at one dims the others.
Everything is in `work/index.html`:

- **Wording**: each section has a title and a short line under it. The short
  lines are placeholders; rewrite them.
- **Linking a section**: change its `<span class="item__link">` to
  `<a class="item__link" href="../work/case-studies/">` and its closing
  `</span>` to `</a>`. Linked sections show a small ↗ on hover.
- **Position**: `--x` / `--y` on each `<li>` place it on wide screens (left and
  top, as a share of the page); `--mx` / `--my` do the same on phones.

## The game

"( Play now )" at the bottom of the Home page opens a round of Fruit Ninja over
the cover; the button reads "( ● Stop )" while it runs, and Esc also stops it.
Fruit is thrown up from below: swipe through it (a quick flick with the mouse,
or drag a finger). Three or more in one swipe is a combo worth that many extra
points; three dropped fruit, or one sliced bomb, ends the game; every 100 points
wins back a dropped fruit. The best score is kept in the visitor's browser.
Everything lives in `assets/js/game.js` (the fruit are drawn in code, near the
top, under "The fruit") and the end of `assets/css/home.css`.

## After editing CSS or JS

Bump the `?v=` number on the `<link>` / `<script>` tags in all three HTML files so
browsers load the new file instead of a cached one.

## Deploying

Any static host works (Vercel, Netlify, GitHub Pages). Links use folder URLs
(`work/`, `about/`), which these hosts resolve to `index.html` automatically.
