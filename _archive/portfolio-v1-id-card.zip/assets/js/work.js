/* ==========================================================================
   Work: a stack of prints.

   Each project is a print in the stack, sitting at its own slight angle.
   "Next" flicks the top print off and tucks it under the stack; "previous"
   brings the bottom print back on top. Arrows, scroll gestures (one gesture,
   one project), swipes and arrow keys all step one project. Clicking the top
   print follows its link.
   ========================================================================== */
(function () {
  'use strict';

  /* ---------- projects: replace these with real ones ----------
     title : read out to screen readers, shown on the placeholder
     image : path to a landscape (4:3) image, e.g. '../assets/img/work/project-01.jpg'
     href  : where the top print links to (optional)
     tone  : placeholder colour used while there is no image */
  const PROJECTS = [
    { title: 'Project 01', image: null, href: null, tone: '#8E8A84' },
    { title: 'Project 02', image: null, href: null, tone: '#5F5B55' },
    { title: 'Project 03', image: null, href: null, tone: '#B6AFA3' },
    { title: 'Project 04', image: null, href: null, tone: '#3E434C' },
    { title: 'Project 05', image: null, href: null, tone: '#A39C90' },
    { title: 'Project 06', image: null, href: null, tone: '#6F7682' },
    { title: 'Project 07', image: null, href: null, tone: '#C6BFB3' },
    { title: 'Project 08', image: null, href: null, tone: '#4E4A45' },
  ];

  const FLICK_MS = 220;
  const GESTURE_GAP = 200;     // ms of wheel silence that ends a scroll gesture
  const MIN_GAP = 240;         // ms between steps

  const doc = document.documentElement;
  const post = document.getElementById('post');
  const stack = document.getElementById('stack');
  const status = document.getElementById('stackStatus');
  if (!post || !stack) return;
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

  // seeded, so every print keeps the same angle on every visit
  let seed = 7;
  const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };

  /* ---------- prints ---------- */

  const prints = PROJECTS.map((p, i) => {
    const el = document.createElement(p.href ? 'a' : 'div');
    el.className = 'print';
    if (p.href) el.href = p.href;
    const r = (rnd() - .5) * 12, dx = (rnd() - .5) * 7, dy = (rnd() - .5) * 8;
    el.dataset.base = 'translate(' + dx.toFixed(2) + '%,' + dy.toFixed(2) + '%) rotate(' + r.toFixed(2) + 'deg)';
    el.style.setProperty('--r', r.toFixed(2) + 'deg');
    el.style.setProperty('--dx', dx.toFixed(2) + '%');
    el.style.setProperty('--dy', dy.toFixed(2) + '%');
    el.style.background = p.tone;
    el.innerHTML = p.image
      ? '<img src="' + p.image + '" alt="" draggable="false" decoding="async">'
      : '<span class="print__ph"><b>' + String(i + 1).padStart(2, '0') + '</b><span>' + p.title + '</span></span>';
    el.addEventListener('click', (e) => {
      if (order[0] !== i) { e.preventDefault(); return; }
      if (!p.href) e.preventDefault();
    });
    stack.appendChild(el);
    return el;
  });

  // order[0] is the print on top
  const order = prints.map((_, i) => i);

  function paint() {
    const n = order.length;
    order.forEach((idx, k) => {
      const el = prints[idx];
      el.style.zIndex = String(n - k);
      el.classList.toggle('is-top', k === 0);
      el.setAttribute('aria-hidden', k === 0 ? 'false' : 'true');
      if (el.tagName === 'A') el.tabIndex = k === 0 ? 0 : -1;
    });
    if (status) status.textContent = PROJECTS[order[0]].title;
  }

  /* ---------- stepping ---------- */

  let lastStep = -1e9;

  function next() {
    const el = prints[order[0]];
    order.push(order.shift());
    paint();
    if (reduce) return;
    // the old top print flicks off to the right, then settles at the back
    el.style.zIndex = String(order.length + 1);
    const base = el.dataset.base;
    const a = el.animate([
      { transform: base, opacity: 1 },
      { transform: base + ' translate(16%, -4%) rotate(6deg)', opacity: 0 },
    ], { duration: FLICK_MS, easing: 'cubic-bezier(.4, 0, .2, 1)' });
    a.onfinish = () => { el.style.zIndex = '1'; };
  }

  function prev() {
    order.unshift(order.pop());
    paint();
    if (reduce) return;
    // the bottom print comes back onto the stack from the left
    const el = prints[order[0]];
    const base = el.dataset.base;
    el.animate([
      { transform: base + ' translate(-16%, -4%) rotate(-6deg)', opacity: 0 },
      { transform: base, opacity: 1 },
    ], { duration: FLICK_MS, easing: 'cubic-bezier(.2, 0, .2, 1)' });
  }

  function step(dir) {
    const now = performance.now();
    if (now - lastStep < MIN_GAP) return;
    lastStep = now;
    if (dir > 0) next(); else prev();
  }

  /* ---------- input ---------- */

  document.getElementById('next').addEventListener('click', () => { lastStep = 0; step(1); });
  document.getElementById('prev').addEventListener('click', () => { lastStep = 0; step(-1); });

  let lastWheel = 0, gestureUsed = false;
  addEventListener('wheel', (e) => {
    e.preventDefault();
    const now = performance.now();
    if (now - lastWheel > GESTURE_GAP) gestureUsed = false;   // a new gesture
    lastWheel = now;
    const d = Math.abs(e.deltaY) >= Math.abs(e.deltaX) ? e.deltaY : e.deltaX;
    if (gestureUsed || Math.abs(d) < 2) return;
    gestureUsed = true;
    step(d > 0 ? 1 : -1);
  }, { passive: false });

  let t0 = null, swiped = false;
  post.addEventListener('touchstart', (e) => { t0 = [e.touches[0].clientX, e.touches[0].clientY]; swiped = false; }, { passive: true });
  post.addEventListener('touchmove', (e) => {
    if (!t0 || swiped) return;
    const dx = e.touches[0].clientX - t0[0], dy = e.touches[0].clientY - t0[1];
    const d = Math.abs(dx) > Math.abs(dy) ? -dx : -dy;
    if (Math.abs(d) > 36) { swiped = true; step(d > 0 ? 1 : -1); }
  }, { passive: true });
  post.addEventListener('touchend', () => { t0 = null; });

  addEventListener('keydown', (e) => {
    if (['ArrowRight', 'ArrowDown', 'PageDown', ' '].includes(e.key)) { e.preventDefault(); step(1); }
    else if (['ArrowLeft', 'ArrowUp', 'PageUp'].includes(e.key)) { e.preventDefault(); step(-1); }
  });

  /* ---------- entrance: the prints are dealt onto the page ---------- */

  paint();
  const begin = () => {
    doc.classList.add('is-ready');
    if (reduce) return;
    order.slice().reverse().forEach((idx, k) => {
      const el = prints[idx], base = el.dataset.base;
      el.animate([
        { transform: base + ' translate(0, 14%) rotate(-4deg)', opacity: 0 },
        { transform: base, opacity: 1 },
      ], { duration: 520, delay: k * 55, easing: 'cubic-bezier(.16, 1, .3, 1)', fill: 'backwards' });
    });
  };
  const fontsReady = document.fonts && document.fonts.ready
    ? Promise.race([document.fonts.ready, new Promise((r) => setTimeout(r, 2000))])
    : Promise.resolve();
  fontsReady.then(begin);
})();
