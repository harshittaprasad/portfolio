/* ==========================================================================
   Lilies: charcoal botanical artwork with a petal-by-petal bloom.

   The artwork is two scanned lilies (assets/img/lily-*.webp: charcoal on a
   transparent background). To bloom, each flower head is cut into soft-edged
   wedges, one per petal, with the cuts placed in the gaps between petals.
   The sequence: the stem grows up, a closed bud appears (every petal furled
   small and turned towards the way the flower faces), then the petals open
   one at a time, nearest the facing direction first, each on a lightly
   under-damped spring so it overshoots a touch and settles. When the bloom
   ends the untouched artwork is drawn, so the final frame is exact.

   Layers inside the container:
     stem : everything outside the flower head (twigs, specks), static
     head : the flower head, repainted while blooming

   Public API:
     Lily.render(container, name, { bloom: bool, delay: ms, autoplay: bool })
       -> { el, layers: { stem, head }, base: [x%, y%], head: [x%, y%], play(), replay(), ready }
   ========================================================================== */
(function (global) {
  'use strict';

  const IMG_BASE = (() => {
    const s = document.currentScript && document.currentScript.src;
    return s ? new URL('../img/', s).href : 'assets/img/';
  })();

  /* Ink-wash lilies with stems and leaves. Image size, flower centre and
     head radius are in source pixels.
     gaps: angles (deg, 0 = right, clockwise) of the spaces between petals.
     axis: the direction the flower faces; the bud points this way. */
  const SPECS = {
    left:  { src: 'lily-left.webp',  w: 960, h: 1557, c: [300, 675], r: 650, gaps: [18, 78, 145, 222, 288, 332], axis: 300, seed: 41 },
    right: { src: 'lily-right.webp', w: 825, h: 1149, c: [495, 600], r: 530, gaps: [27, 88, 142, 225, 302, 347], axis: 262, seed: 7 },
  };
  SPECS.mini = SPECS.right;

  const DEG = Math.PI / 180;
  const clamp01 = (t) => (t < 0 ? 0 : t > 1 ? 1 : t);
  const lerp = (a, b, t) => a + (b - a) * t;
  // a lightly under-damped spring: starts gently, overshoots a touch, settles
  const unfurl = (x) => {
    if (x <= 0) return 0;
    if (x >= 1) return 1;
    const z = .68, w = 6.6, wd = w * Math.sqrt(1 - z * z);
    return 1 - Math.exp(-z * w * x) * (Math.cos(wd * x) + (z * w / wd) * Math.sin(wd * x));
  };
  const angDiff = (a, b) => {
    let d = (a - b) % (Math.PI * 2);
    if (d > Math.PI) d -= Math.PI * 2;
    if (d < -Math.PI) d += Math.PI * 2;
    return d;
  };

  function seeded(seed) {
    let a = seed >>> 0;
    return () => {
      a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  function canvas(w, h) {
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(w));
    c.height = Math.max(1, Math.round(h));
    return c;
  }

  const images = {};
  function load(src) {
    if (!images[src]) {
      images[src] = new Promise((resolve, reject) => {
        const img = new Image();
        img.decoding = 'async';
        img.onload = () => resolve(img);
        img.onerror = reject;
        img.src = IMG_BASE + src + '?v=3';   // bump when the artwork changes
      });
    }
    return images[src];
  }

  /* One driver for every bloom on the page. */
  const blooming = new Set();
  function tick(now) {
    for (const step of blooming) if (step(now)) blooming.delete(step);
    if (blooming.size) requestAnimationFrame(tick);
  }

  function render(container, name, opts) {
    opts = opts || {};
    const sp = SPECS[name];
    if (!container || !sp) return null;

    // geometry first, so layout and positioning never wait for the image
    container.classList.add('lily-root');
    container.style.aspectRatio = sp.w + ' / ' + sp.h;
    container.style.setProperty('--lily-ar', (sp.w / sp.h).toFixed(4));
    container.style.setProperty('--lily-hx', (sp.c[0] / sp.w).toFixed(4));
    container.style.setProperty('--lily-hy', (sp.c[1] / sp.h).toFixed(4));
    const base = [sp.c[0] / sp.w * 100, 100];
    const head = [sp.c[0] / sp.w * 100, sp.c[1] / sp.h * 100];
    container.style.transformOrigin = base[0].toFixed(2) + '% 100%';

    const cssH = container.clientHeight || 400;
    const dpr = Math.min(global.devicePixelRatio || 1, 2);
    const k = Math.min(1, cssH * dpr / sp.h);       // canvas px per source px (never past the source)
    const R = sp.r;

    const stemC = canvas(sp.w * k, sp.h * k);
    const headC = canvas(R * 2 * k, R * 2 * k);
    stemC.className = 'lily-layer lily-layer--stem';
    headC.className = 'lily-layer lily-layer--head';
    for (const c of [stemC, headC]) c.setAttribute('aria-hidden', 'true');
    headC.style.left = ((sp.c[0] - R) / sp.w * 100).toFixed(3) + '%';
    headC.style.top = ((sp.c[1] - R) / sp.h * 100).toFixed(3) + '%';
    headC.style.width = (R * 2 / sp.w * 100).toFixed(3) + '%';
    headC.style.height = (R * 2 / sp.h * 100).toFixed(3) + '%';
    headC.style.transformOrigin = '50% 50%';
    container.appendChild(stemC);
    container.appendChild(headC);

    if (opts.bloom) {
      container.classList.add('is-waiting');
      container.style.setProperty('--bloom-delay', (opts.delay || 0) + 'ms');
    }

    load(sp.src).then((img) => {
      const hs = headC.width, C = hs / 2;          // head canvas size and centre
      const ox = (sp.c[0] - R) * k, oy = (sp.c[1] - R) * k;

      // radial mask: solid inside the head, feathering out at its rim
      const disc = (g) => {
        const gr = g.createRadialGradient(C, C, C * .9, C, C, C);
        gr.addColorStop(0, '#000');
        gr.addColorStop(1, 'rgba(0,0,0,0)');
        g.fillStyle = gr;
        g.fillRect(0, 0, hs, hs);
      };

      // stem layer: the print minus the head
      const sg = stemC.getContext('2d');
      sg.drawImage(img, 0, 0, stemC.width, stemC.height);
      sg.globalCompositeOperation = 'destination-out';
      sg.translate(ox, oy);
      disc(sg);
      sg.setTransform(1, 0, 0, 1, 0, 0);
      sg.globalCompositeOperation = 'source-over';

      // the finished head, exactly as printed
      const full = canvas(hs, hs), fg = full.getContext('2d');
      fg.drawImage(img, -ox, -oy, stemC.width, stemC.height);
      fg.globalCompositeOperation = 'destination-in';
      disc(fg);

      const hg = headC.getContext('2d');
      const paintFinal = () => {
        hg.setTransform(1, 0, 0, 1, 0, 0);
        hg.globalAlpha = 1;
        hg.clearRect(0, 0, hs, hs);
        hg.drawImage(full, 0, 0);
      };

      if (!opts.bloom) { paintFinal(); markReady(); return; }

      // cut the head into one soft wedge per petal, splitting in the gaps between petals
      const rnd = seeded(sp.seed);
      const gaps = sp.gaps;
      const feather = Math.max(2, hs * .018);
      const wedges = gaps.map((g0, i) => {
        let g1 = gaps[(i + 1) % gaps.length];
        if (g1 <= g0) g1 += 360;
        const a0 = g0 * DEG, a1 = g1 * DEG;
        const w = canvas(hs, hs), wg = w.getContext('2d');
        wg.drawImage(full, 0, 0);
        const m = canvas(hs, hs), mg = m.getContext('2d');
        mg.filter = 'blur(' + feather.toFixed(1) + 'px)';
        mg.fillStyle = '#000';
        mg.beginPath();
        mg.moveTo(C, C);
        const steps = 24, pad = 3 * DEG;
        for (let s = 0; s <= steps; s++) {
          const a = lerp(a0 - pad, a1 + pad, s / steps);
          mg.lineTo(C + Math.cos(a) * hs, C + Math.sin(a) * hs);
        }
        mg.closePath();
        mg.fill();
        wg.globalCompositeOperation = 'destination-in';
        wg.drawImage(m, 0, 0);
        return { canvas: w, mid: (a0 + a1) / 2, twist: (rnd() < .5 ? -1 : 1) * (10 + rnd() * 8) * DEG };
      });
      // opening order: petals nearest the facing direction first
      const axis = sp.axis * DEG;
      wedges.forEach((wd) => { wd.toAxis = angDiff(axis, wd.mid); });
      const seq = wedges.slice().sort((a, b) => Math.abs(a.toAxis) - Math.abs(b.toAxis));
      // timed to finish with the page's text and card entrance (~2s)
      const BUD_IN = 0, FIRST = 180, STEP = 130;
      seq.forEach((wd, k) => {
        wd.start = FIRST + k * STEP + (rnd() - .5) * 40;
        wd.dur = 1000 + rnd() * 120;
      });
      const order = seq.slice().reverse();     // the first petal to open sits on top
      const total = Math.max(...wedges.map((w) => w.start + w.dur));

      const frame = (T) => {
        hg.setTransform(1, 0, 0, 1, 0, 0);
        hg.clearRect(0, 0, hs, hs);
        const budA = clamp01((T - BUD_IN) / 260);
        if (budA <= 0) return;
        hg.globalAlpha = budA;
        for (const wd of order) {
          const e = unfurl((T - wd.start) / wd.dur);
          // furled in the bud: short, narrow, turned towards the facing direction
          const len = lerp(.17, 1, e);
          const wid = lerp(.24, 1, Math.pow(Math.max(0, e), 1.3));
          const rot = (wd.toAxis * .82 + wd.twist) * (1 - e);
          hg.setTransform(1, 0, 0, 1, 0, 0);
          hg.translate(C, C);
          hg.rotate(wd.mid + rot);
          hg.scale(len, wid);
          hg.rotate(-wd.mid);
          hg.translate(-C, -C);
          hg.drawImage(wd.canvas, 0, 0);
        }
        hg.globalAlpha = 1;
      };

      // the clock starts on the first frame the page is actually on screen,
      // so a page opened in the background still blooms when it is viewed
      let t0 = null;
      const step = (now) => {
        if (t0 === null) {
          t0 = now + (opts.delay || 0);
          container.classList.remove('is-waiting', 'is-blooming');
          void container.offsetWidth;              // restart the stem's grow animation
          container.classList.add('is-blooming');
        }
        const T = now - t0;
        if (T < total) { frame(T); return false; }
        paintFinal();
        container.classList.remove('is-blooming');
        return true;
      };
      play = () => {
        t0 = null;
        hg.setTransform(1, 0, 0, 1, 0, 0);
        hg.clearRect(0, 0, hs, hs);
        container.classList.add('is-waiting');
        blooming.add(step);
        if (blooming.size === 1) requestAnimationFrame(tick);
      };
      container.classList.add('is-waiting');
      if (pending) play();
      markReady();
    }).catch(() => { container.classList.remove('is-waiting'); markReady(); });

    // play() starts (or replays) the bloom; called before the artwork has
    // loaded, it starts as soon as it is ready. `ready` resolves once loaded.
    let play = null, pending = opts.autoplay !== false, markReady;
    const ready = new Promise((r) => { markReady = r; });
    const replay = () => { if (play) play(); else pending = true; };

    return { el: container, layers: { stem: stemC, head: headC }, base, head, play: replay, replay, ready };
  }

  global.Lily = { render };
})(window);
