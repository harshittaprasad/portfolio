/* ==========================================================================
   Home: the hanging ID card.

   Simulation: extended position-based dynamics (XPBD) with substeps.
   - Lanyard: a chain of particles. Segments resist stretching (with a little
     fabric give) but can go slack; soft "bending" links stop it folding flat.
   - Card: a 2D rigid body hooked to the last particle by a rigid clasp.
   - Drag: a stiff spring between the grabbed point on the card and the
     pointer, so the card pivots naturally around wherever it is held.
   - A hard tether caps total reach so the card cannot be pulled off its cord.
   3D tilt, lift and the wall shadow are derived from the simulated motion.
   The type and the lilies read the card's position/velocity and respond.
   ========================================================================== */
(function () {
  'use strict';

  const doc = document.documentElement;
  const stage = document.getElementById('stage');
  const badge = document.getElementById('badge');
  if (!stage || !badge) return;

  const slot = document.getElementById('cardSlot');
  const shadowEl = document.getElementById('badgeShadow');
  const shadowNear = shadowEl.children[0];
  const shadowFar = shadowEl.children[1];
  const lan = document.getElementById('lanyard');
  const LY = {
    shadow: lan.querySelector('.ly-shadow'),
    ribbon: lan.querySelector('.ly-ribbon'),
    stitch: lan.querySelector('.ly-stitch'),
    edges: lan.querySelector('.ly-edges'),
    line: lan.querySelector('.ly-line'),
    text: lan.querySelector('.ly-text'),
    crimp: lan.querySelector('.ly-crimp'),
    clasp: lan.querySelector('.ly-clasp'),
  };
  const glare = badge.querySelector('.badge__glare');

  const mqReduce = matchMedia('(prefers-reduced-motion: reduce)');
  let reduce = mqReduce.matches;
  if (mqReduce.addEventListener) mqReduce.addEventListener('change', (e) => { reduce = e.matches; });

  /* ---------- tuning ---------- */
  const PIN_EM = 1.35;        // slot centre, from the card's top edge (em)
  const N = 14;               // lanyard particles, anchor included
  const SUBSTEP = 1 / 600;    // target substep length (s)
  const ROPE_MASS = .07;      // per particle, relative to the card (1): enough to lag and bow
  const ROPE_DAMP = 3.4;      // 1/s, air drag on the fabric: the lanyard trails the card
  const LIN_DAMP = .45;       // 1/s, card linear drag
  const ANG_DAMP = 1.6;       // 1/s, card angular drag
  const BOUNCE_DAMP = 3.2;    // 1/s, extra vertical drag: the fabric's give soaks up bounce
  const DEG = Math.PI / 180;

  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

  /* ---------- state ---------- */
  const S = {
    ready: false,
    mode: 'live',             // intro | live | exit
    t: 0,
    vw: 0, vh: 0,
    W: 0, Hc: 0, pinTop: 0, pinLy: 0,
    rest: { x: 0, y: 0 }, restCenter: { x: 0, y: 0 },
    anchor: { x: 0, y: 0, vy: 0, ty: 0 },
    rope: [],
    seg: 0, clasp: 0, reach: 0, g: 0, rw: 0, windA: 0,
    ropeAlpha: 0, bendAlpha: 0, dragAlpha: 0,
    card: { x: 0, y: 0, a: 0, px: 0, py: 0, pa: 0, vx: 0, vy: 0, w: 0, invM: 1, invI: 0 },
    drag: null,
    yaw: 0, yawV: 0, pitch: 0, pitchV: 0, lift: 0, liftV: 0,
    lastTouch: 0, nudged: false,
  };

  /* ---------- layout ---------- */

  function measure() {
    S.vw = innerWidth;
    S.vh = innerHeight;
    S.W = badge.offsetWidth;
    S.Hc = badge.offsetHeight;
    S.pinTop = parseFloat(getComputedStyle(badge).fontSize) * PIN_EM;
    S.pinLy = S.pinTop - S.Hc / 2;
    const r = slot.getBoundingClientRect();
    S.rest.x = r.left + r.width / 2;
    S.rest.y = r.top + S.pinTop;
    S.restCenter.x = S.rest.x;
    S.restCenter.y = S.rest.y - S.pinLy;
  }

  function build() {
    measure();
    const H = S.Hc;
    S.g = H * 16;
    S.clasp = H * .16;
    S.rw = clamp(S.W * .085, 12, 26);
    S.windA = H * .14;

    const an = S.anchor;
    an.x = S.rest.x;
    an.y = -Math.max(60, H * .3);
    an.ty = an.y;
    an.vy = 0;

    const total = S.rest.y - an.y;               // anchor to slot
    const ropeLen = total - S.clasp;
    const stiffness = H * 1.6;                   // whole-lanyard spring constant (card mass = 1)
    const alphaTotal = 1 / stiffness;
    S.ropeAlpha = alphaTotal / (N - 1);          // springs in series
    S.bendAlpha = S.ropeAlpha * 110;
    S.dragAlpha = 1 / (H * 9);
    // pre-shrunk so it hangs at the slot under load (the card plus, on average, half the lanyard)
    S.seg = (ropeLen - S.g * alphaTotal * (1 + (N - 1) * ROPE_MASS / 2)) / (N - 1);
    S.reach = total * 1.05;

    S.rope = [];
    for (let i = 0; i < N; i++) {
      const y = an.y + (i / (N - 1)) * ropeLen;
      S.rope.push({ x: an.x, y, px: an.x, py: y, vx: 0, vy: 0, w: i === 0 ? 0 : 1 / ROPE_MASS });
    }

    const c = S.card;
    c.x = S.rest.x; c.y = S.restCenter.y; c.a = 0;
    c.px = c.x; c.py = c.y; c.pa = 0;
    c.vx = c.vy = c.w = 0;
    c.invM = 1;
    c.invI = 12 / (S.W * S.W + H * H);
    S.yaw = S.yawV = S.pitch = S.pitchV = S.lift = S.liftV = 0;
    S.drag = null;
    doc.classList.remove('is-grabbing');

    LY.text.setAttribute('font-size', (S.rw * .4).toFixed(2));
    LY.text.setAttribute('dy', (S.rw * .14).toFixed(2));
    LY.shadow.setAttribute('transform', 'translate(' + (S.W * .02).toFixed(1) + ' ' + (S.W * .035).toFixed(1) + ')');
    buildClasp();
    measureType();
    measureLilies();
  }

  /* Metal hardware, drawn once per layout in local space (+y points at the card). */
  function buildClasp() {
    const u = S.clasp, rw = S.rw, f = (n) => n.toFixed(2);
    LY.crimp.innerHTML =
      '<rect class="m-body" x="' + f(-rw * .56) + '" y="' + f(-u * .14) + '" width="' + f(rw * 1.12) + '" height="' + f(u * .2) + '" rx="' + f(u * .025) + '"/>' +
      '<path class="m-line" d="M' + f(-rw * .5) + ',' + f(-u * .075) + 'H' + f(rw * .5) + 'M' + f(-rw * .5) + ',' + f(-u * .005) + 'H' + f(rw * .5) + '"/>' +
      '<rect class="m-hi" x="' + f(-rw * .45) + '" y="' + f(-u * .125) + '" width="' + f(rw * .13) + '" height="' + f(u * .17) + '"/>';
    LY.clasp.innerHTML =
      '<path class="m-wire" d="M0,' + f(u * .06) + 'V' + f(u * .13) + '"/>' +
      '<circle class="m-wire" cx="0" cy="' + f(u * .18) + '" r="' + f(u * .05) + '"/>' +
      '<rect class="m-body" x="' + f(-u * .05) + '" y="' + f(u * .225) + '" width="' + f(u * .1) + '" height="' + f(u * .125) + '" rx="' + f(u * .02) + '"/>' +
      '<path class="m-body" d="M0,' + f(u * .345) +
        'C' + f(u * .1) + ',' + f(u * .36) + ' ' + f(u * .15) + ',' + f(u * .55) + ' ' + f(u * .135) + ',' + f(u * .7) +
        'C' + f(u * .12) + ',' + f(u * .84) + ' ' + f(u * .05) + ',' + f(u * .9) + ' 0,' + f(u * .9) +
        'C' + f(-u * .07) + ',' + f(u * .9) + ' ' + f(-u * .12) + ',' + f(u * .83) + ' ' + f(-u * .12) + ',' + f(u * .72) +
        'C' + f(-u * .12) + ',' + f(u * .6) + ' ' + f(-u * .08) + ',' + f(u * .4) + ' 0,' + f(u * .345) + 'Z"/>' +
      '<rect class="m-body" x="' + f(u * .12) + '" y="' + f(u * .5) + '" width="' + f(u * .05) + '" height="' + f(u * .07) + '" rx="' + f(u * .01) + '"/>' +
      '<path class="m-line" d="M' + f(-u * .07) + ',' + f(u * .48) + 'C' + f(-u * .095) + ',' + f(u * .58) + ' ' + f(-u * .095) + ',' + f(u * .7) + ' ' + f(-u * .06) + ',' + f(u * .8) + '"/>' +
      '<path class="m-glint" d="M' + f(u * .06) + ',' + f(u * .42) + 'C' + f(u * .1) + ',' + f(u * .5) + ' ' + f(u * .1) + ',' + f(u * .62) + ' ' + f(u * .085) + ',' + f(u * .72) + '"/>' +
      '<circle class="m-ring" cx="0" cy="' + f(u) + '" r="' + f(u * .1) + '"/>';
  }

  /* ---------- solver ---------- */

  // distance link between two particles; mode 1 = max (rope), -1 = min (bending)
  function link(a, b, rest, alpha, mode) {
    const dx = a.x - b.x, dy = a.y - b.y;
    const len = Math.hypot(dx, dy);
    if (len < 1e-7) return;
    const C = len - rest;
    if ((mode > 0 && C <= 0) || (mode < 0 && C >= 0)) return;
    const w = a.w + b.w;
    if (!w) return;
    const dl = -C / (w + alpha);
    const nx = dx / len * dl, ny = dy / len * dl;
    a.x += nx * a.w; a.y += ny * a.w;
    b.x -= nx * b.w; b.y -= ny * b.w;
  }

  // card-local point -> world offset from the card's centre
  function arm(lx, ly) {
    const c = S.card, ca = Math.cos(c.a), sa = Math.sin(c.a);
    return [lx * ca - ly * sa, lx * sa + ly * ca];
  }

  // rigid clasp between the last lanyard particle and the card's slot
  function solveClasp(p, rest) {
    const c = S.card;
    const r = arm(0, S.pinLy);
    const dx = p.x - (c.x + r[0]), dy = p.y - (c.y + r[1]);
    const len = Math.hypot(dx, dy);
    if (len < 1e-7) return;
    const C = len - rest;
    const nx = dx / len, ny = dy / len;
    const rn = r[0] * ny - r[1] * nx;
    const dl = -C / (p.w + c.invM + c.invI * rn * rn);
    p.x += nx * dl * p.w; p.y += ny * dl * p.w;
    const ix = nx * dl, iy = ny * dl;
    c.x -= ix * c.invM; c.y -= iy * c.invM;
    c.a -= c.invI * (r[0] * iy - r[1] * ix);
  }

  // pull a point on the card toward a fixed target; with maxLen it only acts beyond that distance
  function pullCard(lx, ly, tx, ty, alpha, maxLen) {
    const c = S.card;
    const r = arm(lx, ly);
    const dx = c.x + r[0] - tx, dy = c.y + r[1] - ty;
    const len = Math.hypot(dx, dy);
    if (len < 1e-7) return;
    const C = maxLen == null ? len : len - maxLen;
    if (C <= 0) return;
    const nx = dx / len, ny = dy / len;
    const rn = r[0] * ny - r[1] * nx;
    const dl = -C / (c.invM + c.invI * rn * rn + alpha);
    const ix = nx * dl, iy = ny * dl;
    c.x += ix * c.invM; c.y += iy * c.invM;
    c.a += c.invI * (r[0] * iy - r[1] * ix);
  }

  function pullParticle(p, tx, ty, alpha) {
    const dx = p.x - tx, dy = p.y - ty;
    const len = Math.hypot(dx, dy);
    if (len < 1e-7) return;
    const dl = -len / (p.w + alpha);
    p.x += dx / len * dl * p.w;
    p.y += dy / len * dl * p.w;
  }

  function step(h, tx, ty) {
    const c = S.card, rope = S.rope, g = S.g, an = S.anchor;
    S.t += h;

    if (S.mode === 'intro') {
      an.y += an.vy * h;
      if (an.y >= an.ty) { an.y = an.ty; an.vy = 0; S.mode = 'live'; S.lastTouch = S.t; }
    } else if (S.mode === 'exit') {
      an.vy -= g * 2.4 * h;
      an.y += an.vy * h;
    }
    const a0 = rope[0];
    a0.x = an.x; a0.y = an.y;

    // ambient air: layered slow sines, never quite periodic
    let wind = 0;
    if (!reduce && S.mode === 'live') {
      const t = S.t;
      wind = S.windA * (Math.sin(t * .71) * .55 + Math.sin(t * 1.37 + 1.9) * .3 + Math.sin(t * .23 + .7) * .45);
    }

    const dR = Math.exp(-ROPE_DAMP * h), dL = Math.exp(-LIN_DAMP * h), dA = Math.exp(-ANG_DAMP * h);
    const dV = Math.exp(-BOUNCE_DAMP * h);
    for (let i = 1; i < N; i++) {
      const p = rope[i];
      p.vx = p.vx * dR + wind * .5 * h;
      p.vy = p.vy * dR + g * h;
      p.px = p.x; p.py = p.y;
      p.x += p.vx * h; p.y += p.vy * h;
    }
    c.vx = c.vx * dL + wind * h;
    c.vy = c.vy * dL * dV + g * h;
    c.w *= dA;
    c.px = c.x; c.py = c.y; c.pa = c.a;
    c.x += c.vx * h; c.y += c.vy * h; c.a += c.w * h;

    const ih2 = 1 / (h * h);
    const d = S.drag;
    if (d) {
      if (d.kind === 'card') pullCard(d.lx, d.ly, tx, ty, S.dragAlpha * ih2);
      else pullParticle(rope[d.idx], tx, ty, S.dragAlpha * 4 * ih2);
    }
    for (let i = 0; i < N - 1; i++) link(rope[i], rope[i + 1], S.seg, S.ropeAlpha * ih2, 1);
    for (let i = 0; i < N - 2; i++) link(rope[i], rope[i + 2], S.seg * 1.7, S.bendAlpha * ih2, -1);
    solveClasp(rope[N - 1], S.clasp);
    pullCard(0, S.pinLy, an.x, an.y, 0, S.reach);

    const vmax = S.Hc * 28;
    for (let i = 1; i < N; i++) {
      const p = rope[i];
      p.vx = clamp((p.x - p.px) / h, -vmax, vmax);
      p.vy = clamp((p.y - p.py) / h, -vmax, vmax);
    }
    c.vx = clamp((c.x - c.px) / h, -vmax, vmax);
    c.vy = clamp((c.y - c.py) / h, -vmax, vmax);
    c.w = clamp((c.a - c.pa) / h, -40, 40);
  }

  /* ---------- tilt, lift (frame-rate springs) ---------- */

  function springs(dt) {
    const c = S.card;
    const holding = S.drag && S.drag.kind === 'card';
    let ty = clamp(c.vx * .016, -26, 26);
    let tp = clamp(c.vy * -.011, -18, 18);
    if (holding) {
      ty += clamp(S.drag.lx / (S.W / 2), -1, 1) * 10;
      tp += clamp(-S.drag.ly / (S.Hc / 2), -1, 1) * 8;
    }
    if (!reduce && S.mode === 'live') ty += Math.sin(S.t * .53 + .4) * 2.4 + Math.sin(S.t * 1.13) * .8;
    S.yawV += ((ty - S.yaw) * 55 - S.yawV * 3.4) * dt;
    S.yaw += S.yawV * dt;
    S.pitchV += ((tp - S.pitch) * 70 - S.pitchV * 5.5) * dt;
    S.pitch += S.pitchV * dt;
    S.liftV += (((holding ? 1 : 0) - S.lift) * 140 - S.liftV * 17) * dt;
    S.lift += S.liftV * dt;
  }

  /* ---------- render ---------- */

  function render() {
    const c = S.card;
    const ca = Math.cos(c.a), sa = Math.sin(c.a);
    const pinX = c.x - sa * S.pinLy, pinY = c.y + ca * S.pinLy;
    const x = pinX - S.W / 2, y = pinY - S.pinTop;
    const lift = Math.max(0, S.lift);
    const sc = 1 + S.lift * .035;

    badge.style.transform =
      'translate3d(' + x.toFixed(2) + 'px,' + y.toFixed(2) + 'px,0) rotate(' + c.a.toFixed(4) + 'rad) ' +
      'perspective(' + Math.round(S.Hc * 3.2) + 'px) rotateX(' + S.pitch.toFixed(2) + 'deg) rotateY(' + S.yaw.toFixed(2) + 'deg) scale(' + sc.toFixed(4) + ')';

    // shadow on the wall: light from the upper left; lifting pushes it further and softer
    const ox = S.W * (.02 + lift * .06), oy = S.W * (.035 + lift * .1);
    shadowEl.style.transform =
      'translate3d(' + (x + ox).toFixed(2) + 'px,' + (y + oy).toFixed(2) + 'px,0) rotate(' + c.a.toFixed(4) + 'rad) ' +
      'scale(' + (Math.cos(S.yaw * DEG) * sc).toFixed(4) + ',' + (Math.cos(S.pitch * DEG) * sc).toFixed(4) + ')';
    shadowNear.style.opacity = (1 - lift * .65).toFixed(3);
    shadowFar.style.opacity = (.5 + lift * .5).toFixed(3);
    glare.style.setProperty('--gx', (62 - S.yaw * 2.2 + c.a * 40).toFixed(1) + '%');

    drawLanyard(pinX, pinY);
  }

  function drawLanyard(pinX, pinY) {
    const rope = S.rope, n = rope.length, SPS = 4;
    const pts = [];
    for (let i = 0; i < n - 1; i++) {
      const p0 = rope[Math.max(0, i - 1)], p1 = rope[i], p2 = rope[i + 1], p3 = rope[Math.min(n - 1, i + 2)];
      for (let s = 0; s < SPS; s++) {
        const t = s / SPS, t2 = t * t, t3 = t2 * t;
        pts.push([
          .5 * (2 * p1.x + (p2.x - p0.x) * t + (2 * p0.x - 5 * p1.x + 4 * p2.x - p3.x) * t2 + (3 * p1.x - p0.x - 3 * p2.x + p3.x) * t3),
          .5 * (2 * p1.y + (p2.y - p0.y) * t + (2 * p0.y - 5 * p1.y + 4 * p2.y - p3.y) * t2 + (3 * p1.y - p0.y - 3 * p2.y + p3.y) * t3),
        ]);
      }
    }
    pts.push([rope[n - 1].x, rope[n - 1].y]);

    const m = pts.length;
    const acc = [0];
    for (let i = 1; i < m; i++) acc.push(acc[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
    const total = acc[m - 1] || 1;

    // near the clasp the ribbon twists with the card, showing more of its edge
    const twist = S.yaw * DEG * 1.4;
    let L = '', R = '', SL = '', SR = '', C = '';
    const Rs = [], SRs = [];
    for (let i = 0; i < m; i++) {
      const a = pts[Math.max(0, i - 1)], b = pts[Math.min(m - 1, i + 1)];
      let tx = b[0] - a[0], ty = b[1] - a[1];
      const tl = Math.hypot(tx, ty) || 1;
      tx /= tl; ty /= tl;
      const u = acc[i] / total;
      const k = u < .5 ? 0 : (u - .5) / .5;
      const hw = S.rw / 2 * (.22 + .78 * Math.abs(Math.cos(twist * k * k)));
      const px = pts[i][0], py = pts[i][1];
      const nx = -ty * hw, ny = tx * hw;
      const lx = (px + nx).toFixed(1), ly = (py + ny).toFixed(1);
      const rx = (px - nx).toFixed(1), ry = (py - ny).toFixed(1);
      const sep = i ? 'L' : 'M';
      L += sep + lx + ',' + ly;
      R += sep + rx + ',' + ry;
      Rs.push(rx + ',' + ry);
      SL += sep + (px + nx * .7).toFixed(1) + ',' + (py + ny * .7).toFixed(1);
      SR += sep + (px - nx * .7).toFixed(1) + ',' + (py - ny * .7).toFixed(1);
      C += sep + px.toFixed(1) + ',' + py.toFixed(1);
    }
    const ribbon = L + 'L' + Rs.reverse().join('L') + 'Z';
    LY.ribbon.setAttribute('d', ribbon);
    LY.shadow.setAttribute('d', ribbon);
    LY.edges.setAttribute('d', L + R);
    LY.stitch.setAttribute('d', SL + SR);
    LY.line.setAttribute('d', C);

    // hardware: crimp on the ribbon end, clasp swinging from it to the card's slot
    const e = pts[m - 1], e0 = pts[m - 2];
    const endTw = Math.abs(Math.cos(twist));
    const crimpAng = Math.atan2(e[1] - e0[1], e[0] - e0[0]) / DEG - 90;
    LY.crimp.setAttribute('transform', 'translate(' + e[0].toFixed(1) + ' ' + e[1].toFixed(1) + ') rotate(' + crimpAng.toFixed(2) + ') scale(' + (.25 + .75 * endTw).toFixed(3) + ' 1)');
    const claspAng = Math.atan2(pinY - e[1], pinX - e[0]) / DEG - 90;
    LY.clasp.setAttribute('transform', 'translate(' + e[0].toFixed(1) + ' ' + e[1].toFixed(1) + ') rotate(' + claspAng.toFixed(2) + ')');
  }

  /* ---------- type reacts to the card ---------- */

  const letters = Array.prototype.map.call(document.querySelectorAll('.hero [data-ch]'), (el) => ({
    el,
    inner: el.parentElement,
    line: el.parentElement.parentElement,
    bx: 0, by: 0, x: 0, y: 0, vx: 0, vy: 0, ox: 0, oy: 0,
  }));

  function measureType() {
    for (const L of letters) {
      L.el.style.transform = '';
      const r = L.el.getBoundingClientRect();
      const inn = L.inner.getBoundingClientRect();
      const ln = L.line.getBoundingClientRect();
      L.bx = ln.left + (r.left - inn.left) + r.width / 2;
      L.by = ln.top + (r.top - inn.top) + r.height / 2;
      L.x = L.y = L.vx = L.vy = L.ox = L.oy = 0;
    }
  }

  // repulsion field around the card's centre; letters respond to the change from rest
  function field(px, py, cx, cy, R) {
    const dx = px - cx, dy = py - cy, d = Math.hypot(dx, dy) || 1;
    const s = 1 - d / R;
    if (s <= 0) return 0;
    return s * s * (3 - 2 * s) / d;
  }

  function reactType(dt) {
    if (reduce) return;
    const c = S.card, rc = S.restCenter;
    const R = S.Hc * 1.05, amp = S.Hc * .05;
    for (const L of letters) {
      const fa = field(L.bx, L.by, c.x, c.y, R), fb = field(L.bx, L.by, rc.x, rc.y, R);
      const tx = ((L.bx - c.x) * fa - (L.bx - rc.x) * fb) * amp;
      const ty = ((L.by - c.y) * fa - (L.by - rc.y) * fb) * amp;
      L.vx += ((tx - L.x) * 85 - L.vx * 10) * dt;
      L.vy += ((ty - L.y) * 85 - L.vy * 10) * dt;
      L.x += L.vx * dt;
      L.y += L.vy * dt;
      if (Math.abs(L.x - L.ox) > .03 || Math.abs(L.y - L.oy) > .03) {
        L.ox = L.x; L.oy = L.y;
        L.el.style.transform = 'translate3d(' + L.x.toFixed(2) + 'px,' + L.y.toFixed(2) + 'px,0) rotate(' + (L.x * .3).toFixed(2) + 'deg)';
      }
    }
  }

  /* ---------- lilies react to the card ---------- */

  const lilies = [];

  function renderLilies() {
    if (!window.Lily) return;
    document.querySelectorAll('.stage > [data-lily]').forEach((el, i) => {
      // started by start() together with the text and the card; the right one a beat later
      const h = window.Lily.render(el, el.dataset.lily, { bloom: !reduce, autoplay: false, delay: [0, 120][i] || 0 });
      if (h) lilies.push(Object.assign(h, { ph: i * 2.1 + .5, a: 0, av: 0, ha: 0, hav: 0, sa: 0, sav: 0, bx: 0, by: 0, hx: 0, hy: 0 }));
    });
  }

  function measureLilies() {
    for (const l of lilies) {
      l.el.style.transform = '';
      const r = l.el.getBoundingClientRect();
      l.bx = r.left + r.width * l.base[0] / 100;
      l.by = r.top + r.height * l.base[1] / 100;
      l.hx = r.left + r.width * l.head[0] / 100;
      l.hy = r.top + r.height * l.head[1] / 100;
    }
  }

  function reactLilies(dt) {
    const c = S.card;
    for (const l of lilies) {
      const dx = l.hx - c.x, dy = l.hy - c.y, d = Math.hypot(dx, dy);
      const near = clamp(1 - d / (S.vw * .6), 0, 1);
      let target = 0;
      if (!reduce) {
        target = clamp(c.vx * .0024 * (.3 + near), -4.5, 4.5);
        const R = S.Hc * 1.3;
        if (d < R) { const s = 1 - d / R; target += Math.sign(dx) * s * s * 7; }
        target += Math.sin(S.t * .62 + l.ph) * 1 + Math.sin(S.t * 1.31 + l.ph * 2) * .35;
      }
      // stem: slow plant spring
      l.av += ((target - l.a) * 14 - l.av * 2.6) * dt;
      l.a += l.av * dt;
      // head lags the stem; stamens lag the head and flutter
      l.hav += ((clamp(-l.av * .25, -5, 5) - l.ha) * 38 - l.hav * 4) * dt;
      l.ha += l.hav * dt;
      l.sav += ((clamp(-l.hav * .2 - l.av * .1, -6, 6) - l.sa) * 60 - l.sav * 3) * dt;
      l.sa += l.sav * dt;
      l.el.style.transform = 'rotate(' + l.a.toFixed(3) + 'deg)';
      l.layers.head.style.transform = 'rotate(' + l.ha.toFixed(3) + 'deg)';
      if (l.layers.stamens) l.layers.stamens.style.transform = 'rotate(' + (l.ha + l.sa).toFixed(3) + 'deg)';
    }
  }

  /* ---------- loop ---------- */

  let last = 0;
  function frame(now) {
    requestAnimationFrame(frame);
    if (!S.ready) return;
    const dt = Math.min(last ? (now - last) / 1000 : 1 / 60, 1 / 30);
    last = now;

    const n = Math.max(1, Math.round(dt / SUBSTEP));
    const h = dt / n;
    const d = S.drag;
    // the pointer target is interpolated across substeps so motion stays smooth
    const fx = d ? d.atX : 0, fy = d ? d.atY : 0;
    for (let i = 1; i <= n; i++) {
      const k = i / n;
      step(h, d ? fx + (d.ptrX - fx) * k : 0, d ? fy + (d.ptrY - fy) * k : 0);
    }
    if (d) { d.atX = d.ptrX; d.atY = d.ptrY; }

    // the card leans very slightly towards a cursor that comes near it
    if (ptr.on && !S.drag && S.mode === 'live' && !reduce) {
      const c = S.card, dx = ptr.x - c.x, dy = ptr.y - c.y, d = Math.hypot(dx, dy) || 1;
      const near = clamp(1 - (d - S.Hc * .5) / (S.Hc * .55), 0, 1);
      if (near > 0) {
        c.vx += dx / d * near * S.Hc * .2 * dt;
        S.yawV += dx / d * near * 18 * dt;
      }
    }

    // one gentle tug if nobody has touched the card for a while
    if (!S.nudged && !reduce && S.mode === 'live' && S.t - S.lastTouch > 6) {
      S.nudged = true;
      S.card.vx += S.Hc * 1.1;
      S.yawV += 60;
    }

    springs(dt);
    reactType(dt);
    reactLilies(dt);
    render();
  }

  /* ---------- intro / exit ---------- */

  function intro() {
    const D = S.rest.y + S.Hc * 1.1 + 60;   // start fully above the viewport
    const v0 = S.Hc * 3.3;
    S.anchor.y -= D;
    for (const p of S.rope) { p.y -= D; p.py -= D; p.vy = v0; }
    S.card.y -= D; S.card.py -= D;
    S.card.vy = v0;
    S.card.w = 1.25;
    S.yawV = 80;
    S.anchor.vy = v0;
    S.mode = 'intro';
  }

  window.__pageExit = function () {
    return new Promise((resolve) => {
      if (reduce || !S.ready) { resolve(); return; }
      S.drag = null;
      S.mode = 'exit';
      S.anchor.vy = -S.Hc * 1.5;
      doc.classList.add('is-leaving');
      doc.classList.remove('is-grabbing');
      setTimeout(resolve, 560);
    });
  };

  /* ---------- input ---------- */

  // capture can throw for a pointer that is no longer active; dragging still works without it
  function capture(el, id) {
    try { el.setPointerCapture(id); } catch (err) { /* noop */ }
  }

  function grabCard(e) {
    if (e.button !== 0 || S.mode === 'exit') return;
    e.preventDefault();
    capture(badge, e.pointerId);
    const c = S.card;
    const dx = e.clientX - c.x, dy = e.clientY - c.y;
    const ca = Math.cos(-c.a), sa = Math.sin(-c.a);
    S.drag = {
      kind: 'card', id: e.pointerId,
      lx: dx * ca - dy * sa, ly: dx * sa + dy * ca,
      ptrX: e.clientX, ptrY: e.clientY, atX: e.clientX, atY: e.clientY,
    };
    S.lastTouch = S.t;
    S.nudged = true;
    doc.classList.add('is-grabbing');
    if (document.activeElement !== badge) badge.focus({ preventScroll: true });
  }

  function grabRibbon(e) {
    if (e.button !== 0 || S.mode === 'exit') return;
    e.preventDefault();
    capture(LY.ribbon, e.pointerId);
    let best = 1, bd = Infinity;
    for (let i = 1; i < N; i++) {
      const p = S.rope[i], dd = (p.x - e.clientX) ** 2 + (p.y - e.clientY) ** 2;
      if (dd < bd) { bd = dd; best = i; }
    }
    S.drag = { kind: 'rope', idx: best, id: e.pointerId, ptrX: e.clientX, ptrY: e.clientY, atX: S.rope[best].x, atY: S.rope[best].y };
    S.nudged = true;
    doc.classList.add('is-grabbing');
  }

  function moveDrag(e) {
    const d = S.drag;
    if (!d || d.id !== e.pointerId) return;
    d.ptrX = clamp(e.clientX, 0, S.vw);
    d.ptrY = clamp(e.clientY, 0, S.vh);
  }

  function release(e) {
    if (!S.drag || S.drag.id !== e.pointerId) return;
    S.drag = null;
    S.lastTouch = S.t;
    doc.classList.remove('is-grabbing');
  }

  const ptr = { x: 0, y: 0, on: false };
  addEventListener('pointermove', (e) => {
    if (e.pointerType !== 'mouse') return;
    ptr.x = e.clientX; ptr.y = e.clientY; ptr.on = true;
  }, { passive: true });
  document.documentElement.addEventListener('pointerleave', () => { ptr.on = false; });

  badge.addEventListener('pointerdown', grabCard);
  LY.ribbon.addEventListener('pointerdown', grabRibbon);
  for (const el of [badge, LY.ribbon]) {
    el.addEventListener('pointermove', moveDrag);
    el.addEventListener('pointerup', release);
    el.addEventListener('pointercancel', release);
    el.addEventListener('lostpointercapture', release);
  }

  // brushing past the card with the mouse gives it a small push
  badge.addEventListener('pointermove', (e) => {
    if (S.drag || e.pointerType !== 'mouse' || reduce) return;
    const mx = clamp(e.movementX || 0, -30, 30);
    S.card.vx += mx * S.Hc * .006;
    S.yawV += mx * 1.2;
  });

  badge.addEventListener('keydown', (e) => {
    const c = S.card, k = S.Hc;
    switch (e.key) {
      case 'ArrowLeft': c.vx -= k * 2.4; break;
      case 'ArrowRight': c.vx += k * 2.4; break;
      case 'ArrowUp': c.vy -= k * 3; break;
      case 'ArrowDown': c.vy += k * 1.4; break;
      case 'Enter': case ' ': c.w += 2.4; S.yawV += 160; break;
      default: return;
    }
    S.nudged = true;
    e.preventDefault();
  });

  /* ---------- boot ---------- */

  // text, card and lilies all enter on the same frame, once the lily artwork is ready
  function start() {
    renderLilies();
    const artReady = Promise.all(lilies.map((l) => l.ready));
    Promise.race([artReady, new Promise((r) => setTimeout(r, 2500))]).then(() => {
      badge.classList.add('is-live');
      shadowEl.classList.add('is-live');
      build();
      if (!reduce) intro();
      S.ready = true;
      render();
      doc.classList.add('is-ready');
      for (const l of lilies) l.play();
      setTimeout(() => doc.classList.add('is-settled'), 2000);
    });
  }

  let resizeTimer = 0;
  addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => { if (S.ready && S.mode !== 'exit') build(); }, 140);
  });

  // returning via the back button restores this page from cache mid-exit: reset it
  addEventListener('pageshow', (e) => {
    if (!e.persisted || !S.ready) return;
    doc.classList.remove('is-leaving', 'is-grabbing');
    build();
    if (!reduce) {
      intro();
      for (const l of lilies) l.replay();
    }
  });

  const fontsReady = document.fonts && document.fonts.ready
    ? Promise.race([document.fonts.ready, new Promise((r) => setTimeout(r, 2500))])
    : Promise.resolve();
  fontsReady.then(start);
  requestAnimationFrame(frame);
})();
