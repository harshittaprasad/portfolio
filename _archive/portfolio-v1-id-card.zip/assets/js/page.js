/* Inner pages: bloom the lily, then play the entrance. */
(function () {
  'use strict';
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const lilies = [];
  // the title and the lily enter together, once the artwork is ready
  const start = () => {
    document.querySelectorAll('[data-lily]').forEach((el) => {
      const h = window.Lily && window.Lily.render(el, el.dataset.lily, { bloom: !reduce, autoplay: false });
      if (h) lilies.push(h);
    });
    const artReady = Promise.all(lilies.map((h) => h.ready));
    Promise.race([artReady, new Promise((r) => setTimeout(r, 2500))]).then(() => {
      document.documentElement.classList.add('is-ready');
      lilies.forEach((h) => h.play());
    });
  };
  // back/forward restores the page from cache with the flower already open: bloom again
  addEventListener('pageshow', (e) => {
    if (e.persisted && !reduce) lilies.forEach((h) => h.replay());
  });
  const fontsReady = document.fonts && document.fonts.ready
    ? Promise.race([document.fonts.ready, new Promise((r) => setTimeout(r, 2500))])
    : Promise.resolve();
  fontsReady.then(start);
})();
