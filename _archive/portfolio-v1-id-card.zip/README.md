# Harshita Prasad: portfolio

Static site, no build step. Plain HTML, CSS and JavaScript.

```
index.html            Home: fixed 100vh landing with the hanging ID card
work/index.html       Work (placeholder, to be designed)
about/index.html      About me (placeholder, to be designed)
assets/css/base.css   Shared tokens, header/nav, footer, star cursor, lilies, grain
assets/css/home.css   Home layout, card, lanyard
assets/css/page.css   Inner page layout
assets/js/site.js     Star cursor, page-exit hook, file:// link fix (all pages)
assets/js/lily.js     Lily artwork placement and the petal-by-petal bloom
assets/js/home.js     Card + lanyard physics, tilt, shadow, type/lily reactions
assets/js/page.js     Inner page entrance
assets/img/           Favicon, lily-left.webp / lily-right.webp; put portrait.jpg here
```

## Run locally

```bash
python3 -m http.server 5173
```

Then open http://localhost:5173. Opening `index.html` directly from disk also works.

## ID card photo

The card photo is `assets/img/portrait.jpg` (cropped to the frame's portrait
shape, 520x600). To change it, replace that file and bump the `?v=` on its
`<img>` in `index.html`. It is shown as is, without a colour filter.

## Lily artwork

`assets/img/lily-left.webp` and `lily-right.webp` are the ink-wash lilies (flower,
stem and leaves) taken from the homepage mockup, cleaned, with the background
removed and enlarged 1.5x. Make sure you have the rights to that artwork before
publishing. Any ink-on-white lily scan can replace them: save it with a
transparent background, then update its size, flower centre and petal-gap angles
in the `SPECS` table in `lily.js`, and bump the `?v=` on the image URL there.
Both images are cropped at their outer edge and bottom, which the CSS keeps
against the screen edge.

## Work page

`work/index.html` is a stack of prints on a white, baby-pink polka-dot page, with "somewhere / between /
thought / and making" around it and arrows either side. Each scroll gesture, swipe,
arrow key or arrow click moves to the next project; clicking the top print
follows its link. Projects are listed at the top of `assets/js/work.js`:

```js
{ title: 'Project 01', image: '../assets/img/work/project-01.jpg', href: '../work/project-01/' }
```

Use landscape (4:3) images. Until an `image` is set, a numbered placeholder print
is shown.

## Building the About page

Replace the contents of `<main class="sub">` in `about/index.html`. Keep the
`<header>` block so navigation stays identical; the active page is marked with
`aria-current="page"`.

## Deploying

Any static host works (Vercel, Netlify, GitHub Pages). Links use folder URLs
(`work/`, `about/`), which these hosts resolve to `index.html` automatically.
