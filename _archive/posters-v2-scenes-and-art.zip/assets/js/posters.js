/* ==========================================================================
   Project posters, played on hover (styles in posters.css).

   Each poster is built from an entry in POSTERS below into any element
   marked [data-poster="<name>"]. On the Work page that is each project's
   .proj__media; in _posters/poster.html it is a 1320 x 750 frame that
   render.sh turns into the still assets/img/projects/project-N.jpg.

   There are two kinds:
   - the two products (FlowLedger, Zineps) show full-bleed pictures of the
     work, cutting between scenes and creeping in on hover;
   - the two research papers show generative art drawn in code (ART below),
     each drawing the paper's idea, which comes alive on hover.
   Both carry the same small text: labels in the corners and a list
   scrolling up the right edge, in one colour that contrasts with the
   graphic. Leaving a card brings its poster back to the still.

   To change a poster, edit its entry:
     ink    : the colour of all the text, chosen to contrast with the graphic
     halo   : 'dark' or 'light', a soft glow behind the text so it holds over
              busy parts of a picture (or leave it out)
     veil   : a light tint laid over the pictures, so the text stands out
     acc    : a colour shown while the first picture loads
     pics   : 3 or 4 full-bleed pictures it cuts between (paths from the site
              root); _posters/scene.html builds them, scenes.sh renders them
     art    : instead of pics, the name of a drawing in ART
     list   : what scrolls up the right edge
     tl, tr, bl, br, float : the small labels (use \n for a line break)
   ========================================================================== */
(function () {
  'use strict';

  const POSTERS = {
    flowledger: {
      n: 1, acc: '#0057E0', ink: '#FFE04A', halo: 'dark', veil: 'rgba(0, 38, 130, .2)',
      pics: ['assets/img/projects/scenes/flowledger-1.jpg', 'assets/img/projects/scenes/flowledger-2.jpg', 'assets/img/projects/scenes/flowledger-3.jpg'],
      list: ['Net liquidity', 'AI forecast', 'Smart alerts', 'Budgets', 'Savings pots', 'Upcoming bills', 'Transactions', 'Search', 'Split', 'Remind', 'Settle up', 'AI report', 'Heatmap', 'Subscriptions', 'Privacy mode', 'Export CSV'],
      tl: '01', tr: '2026', bl: 'Mobile app\nFintech · AI', br: 'UX/UI\ncase study', float: 'N°01',
    },
    zineps: {
      n: 2, acc: '#0A1C2E', ink: '#FF8FB4', halo: 'dark', veil: 'rgba(4, 12, 24, .15)',
      pics: ['assets/img/projects/scenes/zineps-1.jpg', 'assets/img/projects/scenes/zineps-2.jpg', 'assets/img/projects/scenes/zineps-3.jpg', 'assets/img/projects/scenes/zineps-4.jpg'],
      list: ['Orders', 'Labels', 'Rates', 'Tracking', 'Returns', 'Analytics', 'Shipping AI', 'DHL', 'UPS', 'DPD', 'FedEx', 'PostNL', 'Amsterdam', 'Milan', 'Berlin', '200+ countries'],
      tl: '02', tr: '2026', bl: 'Website\nredesign', br: 'Product UI\nresponsive', float: 'N°02',
    },
    inclusivity: {
      n: 3, acc: '#C6BEDB', ink: '#E4400F', halo: 'light', art: 'calm',
      list: ['Autism', 'ADHD', 'OCD', 'Tourette’s', 'Dyspraxia', 'Sensory processing', 'Anxiety', 'Interviews', 'Card sorting', 'Co-design', 'NASA-TLX', 'Overload scale', 'Pacing', 'Sanctuary', 'Density', 'E-DUX'],
      tl: '03', tr: '2026', bl: 'Research\npaper', br: 'Neuroinclusive\nUX', float: 'N°03',
    },
    companions: {
      n: 4, acc: '#E9BBA0', ink: '#1F43D6', halo: 'light', art: 'bond',
      list: ['Honest presence', 'Healthy attachment', 'Safe escalation', 'Data dignity', 'Goodbyes', 'Distress', 'Feelings', 'Memory', 'Loneliness', 'Wellbeing', 'Dependency index', 'Conversation audit', 'Co-design', 'Field study', '40 adults', '4 weeks'],
      tl: '04', tr: '2026', bl: 'Research\npaper', br: 'AI\ncompanions', float: 'N°04',
    },
  };

  // a soft glow behind the text, dark under light text and light under dark
  const HALO = {
    dark: '0 0 .5em rgba(0, 0, 0, .55), 0 0 1.4em rgba(0, 0, 0, .3)',
    light: '0 0 .5em rgba(255, 255, 255, .7), 0 0 1.4em rgba(255, 255, 255, .45)',
  };

  /* ---------- the generative art for the research papers ----------
     Each drawing is made at 1320 x 750 and scaled to the card. draw(g, t, a)
     paints one frame: t is the time in seconds, a is how alive it is, from 0
     (the still) to 1 (hovered). At a = 0 every frame is the same still. */

  const W = 1320, H = 750;
  const seeded = (seed) => () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  const smooth = (a, b, x) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); };

  const ART = {
    // Redesigning Inclusivity: overload settling into calm. Lines crowd and
    // jitter on the left (sensory overload) and settle into even waves that
    // part around a soft glow on the right (the sensory sanctuary). On hover
    // the overload flickers and the calm waves breathe.
    calm() {
      const rnd = seeded(7);
      const tab = Array.from({ length: 4096 }, rnd);
      const noise = (x) => { const i = Math.floor(x), f = x - i, s = f * f * (3 - 2 * f); return tab[i & 4095] * (1 - s) + tab[(i + 1) & 4095] * s; };
      const CX = 1000, CY = 375, CR = 150, RR = 118;
      // a line far from the glow bends around it like water round a stone
      const stream = (b, dx) => {
        const sgn = b < 0 ? -1 : 1, bb = Math.abs(b);
        let y = Math.max(bb, Math.sqrt(Math.max(0, RR * RR - dx * dx)) + bb * .5 + 1);
        for (let k = 0; k < 24; k++) {
          const q = dx * dx + y * y, f = y - RR * RR * y / q - bb, df = 1 - RR * RR * (dx * dx - y * y) / (q * q);
          y = Math.max(y - f / df, 1);
        }
        return sgn * y;
      };
      const LINES = 44, gap = (H + 80) / LINES;
      // the parts of every line that never move, worked out once
      const xs = [], base = [], over = [];
      for (let x = -10; x <= W + 10; x += 3) { xs.push(x); over.push(Math.pow(1 - smooth(.08, .7, x / W), 1.6)); }
      for (let i = 0; i < LINES; i++) {
        const y0 = -40 + i * gap + gap * .5, row = [];
        xs.forEach((x, k) => {
          const jitter = (noise(x * .09 + i * 31.7) - .5) * 46 + (noise(x * .023 + i * 7.1) - .5) * 70;
          const calm = Math.sin(x / 140 + i * .35) * 5 * (1 - Math.exp(-((x - CX) ** 2) / 60000));
          row.push(CY + stream(y0 - CY, x - CX) + calm + jitter * over[k]);
        });
        base.push(row);
      }
      return (g, t, a) => {
        const bg = g.createRadialGradient(CX, CY, 0, CX, CY, 620);
        bg.addColorStop(0, '#E6E1F1'); bg.addColorStop(1, '#C6BEDB');
        g.fillStyle = bg; g.fillRect(0, 0, W, H);
        const r = CR * 1.5 * (1 + a * .05 * Math.sin(t * 1.6));
        const glow = g.createRadialGradient(CX, CY, 0, CX, CY, r);
        glow.addColorStop(0, 'rgba(255, 246, 232, 1)');
        glow.addColorStop(.45, 'rgba(255, 240, 226, .7)');
        glow.addColorStop(1, 'rgba(255, 240, 226, 0)');
        g.fillStyle = glow; g.beginPath(); g.arc(CX, CY, r, 0, Math.PI * 2); g.fill();
        g.lineWidth = 1.15;
        for (let i = 0; i < LINES; i++) {
          g.beginPath();
          const row = base[i];
          for (let k = 0; k < xs.length; k++) {
            const x = xs[k];
            let y = row[k];
            if (a) {
              y += a * ((noise(x * .07 + i * 13.3 + t * 2.2) - .5) * 34 * over[k]
                + Math.sin(x / 120 + i * .35 - t * 1.4) * 4 * (1 - over[k]));
            }
            if (k) g.lineTo(x, y); else g.moveTo(x, y);
          }
          const f = i / (LINES - 1);
          g.strokeStyle = 'rgba(36, 29, 56, ' + (.28 + .32 * Math.sin(Math.PI * f)).toFixed(3) + ')';
          g.stroke();
        }
      };
    },

    // Emotionally Responsible AI Companions: a bond that leaves room. A person
    // (left, brighter) and a companion (right), drawn as field lines between
    // them. Many lines join them; the rest fan out to the edges, to the life
    // outside the app. On hover, small lights travel out along the lines and
    // the companion's glow breathes.
    bond() {
      const P = { x: 505, y: 392, q: 1.75 }, C = { x: 955, y: 356, q: -1 };
      const field = (x, y) => {
        let ex = 0, ey = 0;
        for (const s of [P, C]) { const dx = x - s.x, dy = y - s.y, d2 = dx * dx + dy * dy + 1e-6; ex += s.q * dx / d2; ey += s.q * dy / d2; }
        return [ex, ey];
      };
      const lines = [];
      const N = 92;
      for (let i = 0; i < N; i++) {
        const ang = (i + .5) / N * Math.PI * 2;
        let x = P.x + Math.cos(ang) * 10, y = P.y + Math.sin(ang) * 10;
        const pts = [[x, y]]; let joined = false;
        for (let k = 0; k < 4000; k++) {
          let [ex, ey] = field(x, y); let m = Math.hypot(ex, ey);
          const h = 2.2, mx = x + ex / m * h / 2, my = y + ey / m * h / 2;
          [ex, ey] = field(mx, my); m = Math.hypot(ex, ey);
          x += ex / m * h; y += ey / m * h; pts.push([x, y]);
          if (Math.hypot(x - C.x, y - C.y) < 12) { joined = true; break; }
          if (x < -60 || x > W + 60 || y < -60 || y > H + 60) break;
        }
        const path = new Path2D();
        pts.forEach(([px, py], k) => (k ? path.lineTo(px, py) : path.moveTo(px, py)));
        lines.push({ pts, path, joined });
      }
      const glow = (g, x, y, r, inner, outer) => {
        const gr = g.createRadialGradient(x, y, 0, x, y, r);
        gr.addColorStop(0, inner); gr.addColorStop(.42, outer); gr.addColorStop(1, 'rgba(255, 244, 236, 0)');
        g.fillStyle = gr; g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.fill();
      };
      return (g, t, a) => {
        const bg = g.createRadialGradient(660, 375, 0, 660, 375, 700);
        bg.addColorStop(0, '#F6DCCB'); bg.addColorStop(1, '#E9BBA0');
        g.fillStyle = bg; g.fillRect(0, 0, W, H);
        glow(g, P.x, P.y, 210, 'rgba(255, 250, 244, 1)', 'rgba(255, 238, 224, .62)');
        glow(g, C.x, C.y, 130 * (1 + a * .12 * Math.sin(t * 1.8)), 'rgba(255, 248, 242, .95)', 'rgba(255, 236, 224, .5)');
        g.lineWidth = 1.1;
        for (const l of lines) {
          if (l.joined) g.strokeStyle = 'rgba(62, 31, 26, .5)';
          else {
            const [ex, ey] = l.pts[l.pts.length - 1];
            const lg = g.createLinearGradient(P.x, P.y, ex, ey);
            lg.addColorStop(0, 'rgba(62, 31, 26, .5)'); lg.addColorStop(1, 'rgba(62, 31, 26, .16)');
            g.strokeStyle = lg;
          }
          g.stroke(l.path);
        }
        // lights travelling out along the lines
        if (a) {
          lines.forEach((l, i) => {
            const n = l.pts.length;
            const f = (t * (l.joined ? .16 : .09) + i * .618) % 1;
            const [x, y] = l.pts[Math.min(n - 1, Math.floor(f * n))];
            const fade = l.joined ? Math.sin(Math.PI * f) : 1 - f;
            g.fillStyle = 'rgba(255, 252, 248, ' + (a * .9 * fade).toFixed(3) + ')';
            g.beginPath(); g.arc(x, y, 2.4, 0, Math.PI * 2); g.fill();
          });
        }
        g.fillStyle = '#FFFCF8';
        g.beginPath(); g.arc(P.x, P.y, 5.5, 0, Math.PI * 2); g.fill();
        g.beginPath(); g.arc(C.x, C.y, 3.6, 0, Math.PI * 2); g.fill();
      };
    },
  };

  // a canvas that keeps itself the size of its poster and redraws on demand
  function artCanvas(el, name) {
    const draw = ART[name]();
    const cv = el.querySelector('.poster__art'), g = cv.getContext('2d');
    let t = 0, a = 0, target = 0, raf = 0, last = 0;
    const paint = () => {
      const s = cv.width / W;
      g.setTransform(s, 0, 0, s, 0, 0);
      draw(g, t, a);
    };
    const size = () => {
      const r = cv.getBoundingClientRect(), dpr = Math.min(2, window.devicePixelRatio || 1);
      const w = Math.round(r.width * dpr), h = Math.round(r.height * dpr);
      if (!w || (w === cv.width && h === cv.height)) return;
      cv.width = w; cv.height = h; paint();
    };
    new ResizeObserver(size).observe(cv);
    const tick = (now) => {
      const dt = last ? Math.min(.05, (now - last) / 1000) : 0; last = now;
      t += dt;
      a += (target - a) * Math.min(1, dt * 3.2);             // ease in and out of life
      if (!target && a < .004) { a = 0; t = 0; raf = 0; last = 0; paint(); return; }   // back to the still
      paint();
      raf = requestAnimationFrame(tick);
    };
    return {
      play() { target = 1; if (!raf) { last = 0; raf = requestAnimationFrame(tick); } },
      rest() { target = 0; if (!raf && a) raf = requestAnimationFrame(tick); },
    };
  }

  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const lines = (s) => esc(s).replace(/\n/g, '<br>');

  function build(host, name, root) {
    const p = POSTERS[name];
    if (!p) return null;
    const list = '<ul>' + p.list.map((t) => '<li>' + esc(t) + '</li>').join('') + '</ul>';
    let graphic, count = 0;
    if (p.art) {
      graphic = '<canvas class="poster__art"></canvas>';
    } else {
      count = p.pics.length;
      // only the first picture shows at rest; the others can load later
      graphic = p.pics.map((src, k) =>
        '<img class="poster__img" src="' + root + esc(src) + '" alt="" draggable="false"' + (k ? ' loading="lazy"' : '') + ' style="--k:' + k + '">').join('');
    }

    const el = document.createElement('div');
    el.className = 'poster' + (p.art ? ' poster--art' : '');
    el.setAttribute('aria-hidden', 'true');
    el.style.cssText = '--acc:' + p.acc + '; --ink:' + p.ink + '; --count:' + (count || 1) + '; --slot:2.2s; --swap:poster-swap-' + count;
    if (p.veil) el.style.setProperty('--veil', p.veil);
    if (HALO[p.halo]) el.style.setProperty('--halo', HALO[p.halo]);
    el.innerHTML =
      '<div class="poster__panel">' + graphic + '</div>' +
      '<div class="poster__list"><div class="poster__track">' + list + list + '</div></div>' +
      '<p class="poster__lbl poster__lbl--tl">' + lines(p.tl) + '</p>' +
      '<p class="poster__lbl poster__lbl--tr">' + lines(p.tr) + '</p>' +
      '<p class="poster__lbl poster__lbl--bl">' + lines(p.bl) + '</p>' +
      '<p class="poster__lbl poster__lbl--br">' + lines(p.br) + '</p>' +
      '<p class="poster__lbl poster__lbl--float">' + lines(p.float) + '</p>';
    host.appendChild(el);
    host.classList.add('has-poster');
    if (p.art) el.art = artCanvas(el, p.art);
    return el;
  }

  /* ---------- play on hover, settle back on leave ---------- */

  const RETURN_MS = 650;   // how long the floating label takes to glide home
  const reduce = matchMedia('(prefers-reduced-motion: reduce)');
  const canHover = matchMedia('(hover: hover)');

  function control(el, trigger) {
    let settle = 0;
    const anims = () => el.getAnimations({ subtree: true });
    const glides = (a) => /poster-float/.test(a.animationName || '');
    const play = () => {
      if (reduce.matches) return;
      clearTimeout(settle);
      anims().forEach((a) => { a.updatePlaybackRate(1); a.play(); });
      if (el.art) el.art.play();
    };
    const rest = () => {
      clearTimeout(settle);
      if (el.art) el.art.rest();
      anims().forEach((a) => {
        if (!glides(a)) { a.pause(); a.currentTime = 0; return; }   // the pictures cut back; the list goes home
        // the floating label finishes its loop quickly, which brings it home
        const dur = a.effect.getTiming().duration;
        const left = dur - (a.currentTime % dur);
        if (a.playState === 'running' && left > 30) a.updatePlaybackRate(Math.max(1, left / RETURN_MS));
        else { a.pause(); a.currentTime = 0; }
      });
      settle = setTimeout(() => anims().forEach((a) => { a.pause(); a.currentTime = 0; a.updatePlaybackRate(1); }), RETURN_MS + 40);
    };
    trigger.addEventListener('pointerenter', (e) => { if (e.pointerType !== 'touch' && canHover.matches) play(); });
    trigger.addEventListener('pointerleave', (e) => { if (e.pointerType !== 'touch') rest(); });
    trigger.addEventListener('focus', play);
    trigger.addEventListener('blur', rest);
    return { play, rest };
  }

  // the site root, relative to this page (posters.js lives in assets/js/)
  const me = document.currentScript && document.currentScript.src;
  const root = me ? me.replace(/assets\/js\/posters\.js.*$/, '') : '../';

  document.querySelectorAll('[data-poster]').forEach((host) => {
    const el = build(host, host.dataset.poster, root);
    if (el) el.ctl = control(el, host.closest('a, button') || host);
  });
  window.Posters = { build, control, list: POSTERS };
})();
