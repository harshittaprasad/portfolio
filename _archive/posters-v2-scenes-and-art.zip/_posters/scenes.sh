#!/bin/sh
# Renders the full-bleed pictures behind the FlowLedger and Zineps posters from
# scene.html (the research papers' posters are drawn in code, in posters.js),
# using Google Chrome. Run from this folder:
#   sh scenes.sh                     (all of them)
#   ONLY=zineps-2 sh scenes.sh       (just one)
# Each is 1320 x 750 at 1.5x, saved as ../assets/img/projects/scenes/<name>.jpg.
# Then run render.sh to update the poster stills.
CH="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$HERE/../assets/img/projects/scenes"
mkdir -p "$OUT"
[ -x "$HERE/.crop" ] || swiftc -O "$HERE/crop.swift" -o "$HERE/.crop"
for s in flowledger-1 flowledger-2 flowledger-3 zineps-1 zineps-2 zineps-3 zineps-4; do
  [ -n "$ONLY" ] && [ "$ONLY" != "$s" ] && continue
  "$CH" --headless=new --disable-gpu --hide-scrollbars --user-data-dir="$HERE/.chrome" \
    --allow-file-access-from-files --force-device-scale-factor=1.5 --window-size=1320,1000 \
    --virtual-time-budget=8000 --screenshot="$HERE/scene.png" "file://$HERE/scene.html?s=$s" >/dev/null 2>&1
  "$HERE/.crop" "$HERE/scene.png" "$OUT/$s.jpg" 1980 1125 0.8
  rm -f "$HERE/scene.png"
  echo "scenes/$s.jpg"
done
rm -rf "$HERE/.chrome" "$HERE/.crop"
